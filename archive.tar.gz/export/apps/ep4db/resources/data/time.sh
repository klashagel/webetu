#!/bin/bash
date +%H%M%S


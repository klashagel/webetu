#!/bin/bash
date +%y%m%d


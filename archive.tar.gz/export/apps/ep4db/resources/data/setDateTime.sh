#!/bin/sh
###sudo date +%y%m%d -s "130903"
###date +%y%m%d -s $1
###sudo date +%H%M%S -s "13:20:20"
###date +%H%M%S -s $2
###sleep 1
###hwclock -w   

echo $1 > /tmp/tdate
ye=`cut -c1-2 /tmp/tdate`
mo=`cut -c3-4 /tmp/tdate`
da=`cut -c5-6 /tmp/tdate`
rm /tmp/tdate
date -s "20"$ye"-"$mo"-"$da" "$2
sleep 1
hwclock -w 
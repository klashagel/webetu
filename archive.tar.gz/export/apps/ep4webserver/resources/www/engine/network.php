<?php

$ip = isset($_GET['ip'])?$_GET['ip']:-1;
$netmask = isset($_GET['netmask'])?$_GET['netmask']:-1;
$dhcp = isset($_GET['dhcp'])?$_GET['dhcp']:-1;
$gateway = isset($_GET['gateway'])?$_GET['gateway']:-1;


if ($ip==-1 || $netmask==-1 || $dhcp==-1 || $gateway==-1) {
    header("HTTP/1.0 400 Bad Request");
    echo "network.php failed because ip/netmask/dhcp parameter is missing";
    exit();
}

function exit_with_err($err) {
    header("HTTP/1.0 400 Bad Request");
    echo "network.php $err";
    exit();
}

function exit_with_script_err($err) {
    header("HTTP/1.0 501 Script Error");
    echo "network.php $err";
    exit();
}


if ($dhcp == "0") {

$ip_rule='^([0]{1,3}\.){3}[0]{1,3}$';
if (ereg($ip_rule, $gateway)) {
    $gateway = $ip;
}

$config = "DEVICE=eth0
IPADDR=$ip
HOSTNAME=ETU
ONBOOT=yes
NETMASK=$netmask
GATEWAY=$gateway
BOOTPROTO=none";

} else {
$config = "DEVICE=eth0
BOOTPROTO=dhcp
HOSTNAME=ETU
ONBOOT=yes
USECTL=no
PEERDNS=yes
TYPE=Ethernet";
}

$fh = fopen("/etc/sysconfig/network-scripts/ifcfg-eth0", 'w') or exit_with_script_err("could not open file for writing: ".$path.$filename);
fwrite($fh, $config);
fclose($fh);
exec("/sbin/ifdown eth0");
exec("/sbin/ifup eth0");

header("Content-Type: text/plain");
echo "ok";


?>

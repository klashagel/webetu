<?php

require_once("class_http.php");

$cmd = isset($_GET['cmd'])?$_GET['cmd']:false;
$target = isset($_GET['target'])?$_GET['target']:false;
$filename = isset($_GET['filename'])?$_GET['filename']:false;
$url = isset($_GET['url'])?$_GET['url']:false;

$paths = array("local"=>"/storage/var/etu/settings/", "usb"=>"/mnt/usbstick/etu/settings/", "application_dir"=>"/mnt/usbstick/etu/application/", "platform_dir"=>"/mnt/usbstick/etu/platform/");

if (!$cmd && !$target) {
    header("HTTP/1.0 400 Bad Request");
    echo "settings.php failed because cmd and/or target parameter is missing";
    exit();
}

function exit_with_err($err) {
    header("HTTP/1.0 400 Bad Request");
    echo "settings.php $err";
    exit();
}

function exit_with_usr_err($err) {
    header("HTTP/1.0 503 Service Unavailable");
    echo "settings.php $err";
    exit();
}

function exit_with_script_err($err) {
    header("HTTP/1.0 501 Script Error");
    echo "settings.php $err";
    exit();
}

$path = $paths[$target];
if (!isset($path)) { exit_with_err("failed because of unknown target: $target"); };

if (($target == "usb" || $target == "application_dir" || $target == "platform_dir" ) && file_exists("/mnt/usbstick/NOT_MOUNTED")) {
    exec("mount -n -t vfat /tmp/dev/sda /mnt/usbstick/");
    if (file_exists("/mnt/usbstick/NOT_MOUNTED")) {
        exit_with_usr_err("failed because no USB stick is mounted");
    }
}

if (!file_exists($path)) {
    mkdir($path, 0666, true);
}

switch($cmd) {
    case "list":
        $first = true;
        if (file_exists($path) && $dh = opendir($path)) {
            while (($file = readdir($dh)) != false) {
                if (is_file($path. $file)) {
                    if (!$first) echo ",";
                    $first = false;
                    echo "$file";
                }
            }
        }
    break;
    case "save":
        if (!isset($filename)) { exit_with_err("failed because of missing filename"); };
        if (!isset($url)) { exit_with_err("failed because of missing url: $url"); };
        if (!$h = new http()) {
            exit_with_script_err("failed trying to initialize the http object");
        }
        $h->url = $url;
        if (!$h->fetch($h->url)) {
            exit_with_script_err("had an error attempting to query the url: ".$url);
        }
        $fh = fopen($path.$filename, 'w') or exit_with_script_err("could not open file for writing: ".$path.$filename);
        fwrite($fh, $h->body);
        fclose($fh);

        exec("/bin/sync");

        header("Content-Type: text/plain");
        echo "ok";
    break;
    case "delete":
        // TODO Error checking for missing file
        if (!isset($filename)) { exit_with_err("failed because of missing filename"); };

        unlink($path.$filename);
        exec("/bin/sync");

        header("Content-Type: text/plain");
        echo "ok";
    break;
    case "load":
        // TODO Error checking for missing file
        if (!isset($filename)) { exit_with_err("failed because of missing filename"); };
        header("Content-Type: application/xml; charset=utf-8");
        header('Content-Length: ' . filesize($path.$filename));
        readfile($path.$filename);
    break;
}
?>

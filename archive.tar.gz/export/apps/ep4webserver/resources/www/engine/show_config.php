<?php

function exit_with_err($err) {
    header("HTTP/1.0 400 Bad Request");
    echo "show_network.php $err";
    exit();
}

function exit_with_script_err($err) {
    header("HTTP/1.0 501 Script Error");
    echo "show_network.php $err";
    exit();
}

exec("/sbin/ifconfig eth0 | /usr/bin/head -2 | /usr/bin/tail -1 | /bin/sed 's/.*addr:\\([0-9.]*\\).*Mask:\\([0-9.]*\\).*/\\1\\n\\2/'", $result, $ret);
list($ip, $netmask) = $result;


exec('grep "^BOOTPROTO=dhcp$" /etc/sysconfig/network-scripts/ifcfg-eth0', $dummy, $ret);
if ($ret == 0) {
    $dhcp="1";
} else {
    $dhcp="0";
}


$uptime = 0;
if (file_exists("../uptime")) {
    $uptime_raw = file_get_contents("../uptime");
    $uptime_s = intval($uptime_raw);

    $uptime = (int)($uptime_s / 3600);
}

if (file_exists("../boots")) {
    $boots = file_get_contents("../boots");
}

if (file_exists("../acc_uptime")) {
    $acc_uptime = file_get_contents("../acc_uptime");
}

if (file_exists("../etu/etu_version")) {
    $etu_version = file_get_contents("../etu/etu_version");
}

if (file_exists("../etu/fpga_version")) {
    $fpga_version = file_get_contents("../etu/fpga_version");
}

if (file_exists("/VERSION")) {
    $platform_version = file_get_contents("/VERSION");
} else {
    $platform_version_unavailavle = ' unavailable="true"';
}

$gateway=exec("/sbin/ip  -f inet -o  route show | /bin/grep default | /usr/bin/awk {'print $3;'}");

$ip_rule='^([0-9]{1,3}\.){3}[0-9]{1,3}$';
if (!ereg($ip_rule, $ip)) {
    $ip="0.0.0.0";
}
if (!ereg($ip_rule,$netmask)) {
    $netmask="0.0.0.0";
}
if (!ereg($ip_rule,$gateway)) {
    $gateway="0.0.0.0";
}

header("Content-Type: application/xml; charset=utf-8");

echo <<<END
<unit_data>
<data id="information_etu_version" type="str">$etu_version</data>
<data id="information_fpga_version" type="str">$fpga_version</data>
<data id="information_etu_platform_version" $platform_version_unavailavle type="str">$platform_version</data>
<data id="information_uptime" type="str">$uptime</data>
<data id="information_acc_uptime" type="str">$acc_uptime</data>
<data id="information_boots" type="str">$boots</data>
<data id="conf_ip" type="ip">$ip</data>
<data id="conf_netmask" type="ip">$netmask</data>
<data id="conf_gateway" type="ip">$gateway</data>
<data id="conf_dhcp" type="str">$dhcp</data>
</unit_data>
END;


?>

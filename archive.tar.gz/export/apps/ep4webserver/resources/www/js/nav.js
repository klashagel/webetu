var currPageIndex = -1;
var currNodeName;
var ip = null; // TODO Set to null on discovery page
var DISPLAY_IDLE_TIME = 30 * 60 * 1000;
var distance;

var K_UP = 107;
var K_DOWN = 106;
var K_LEFT = 104;
var K_RIGHT = 108;
var K_ENTER = 99;
var K_DEL = 120;
var K_CANCEL = 118; // v
var K_PGUP = 119; // w
var K_PGDOWN = 115; // s
var K_FUNCTION = 102; // f
/*global G pages updateHeader initMainCont security padStr onClickVal window */

var navctx = (function () {
	var savedContexts, context, popedContext = null;

	savedContexts = [];

	context = function () {
		var onkeypress;

		return {

			fieldJumpCache: [],
			currFieldIndex: -1,
			currLst: null,
			keyHitHook: null,

			enteredValue: "",
			blankValTimer: null,

			xmlPage: null,
			updatevalue: null,

			activate: function () {
				if (onkeypress) {
					document.onkeypress = onkeypress;
				} else {
					document.onkeypress = null;
				}
			},
			disable: function () {
				onkeypress = document.onkeypress;
				document.onkeypress = null;
			}
		};
	};

	return {
		createNewAndActivate: function () {
			if (!!this.active) {
				this.active.disable();
				savedContexts.push(this.active);
			}
			this.active = context();
			this.active.activate();
		},
		pop: function () {
			this.active.disable();
			popedContext = this.active;
			this.active = savedContexts.pop();
			if (!!this.active) {
				this.active.activate();
			}
		},
		undoPop: function () {
			this.active.disable();
			this.active = popedContext;
			if (!!this.active) {
				this.active.activate();
			}
		}
	};
}());
navctx.createNewAndActivate(); // TODO Move to init

var characters = (function () {
	var validChars, validMap, validRevMap;
	validChars = [];
	validMap = [];
	validRevMap = [];

	// Same character may NOT exist in two different places
	validChars.str = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789- ';
	validChars.int = '0123456789';

	function generateMaps(type) {
		var i;
		validMap[type] = [];
		validRevMap[type] = [];
		validRevMap[type][validChars[type].charAt(0)] = validChars[type].charAt(validChars[type].length - 1);
		for (i = 0; i < (validChars[type].length - 1); i++) {
			validMap[type][validChars[type].charAt(i)] = validChars[type].charAt(i + 1);
			validRevMap[type][validChars[type].charAt(i + 1)] = validChars[type].charAt(i);
		}
		validMap[type][validChars[type].charAt(validChars[type].length - 1)] = validChars[type].charAt(0);
	}
	generateMaps("str");
	generateMaps("int");
	validMap.dte = validMap.int;
	validMap.ip = validMap.int;
	validMap.tme = validMap.int;
	validRevMap.dte = validMap.int;
	validRevMap.ip = validMap.int;
	validRevMap.tme = validMap.int;

	return {
		isValid: function (tChar, type) {
      if (validMap[type][tChar] == null) return null; //MW
			return validMap[type][tChar] !== undefined;
		},
		next: function (oldChar, type, direction) {	
			var newChar;

			if (oldChar === -1) {
				oldChar = validChars[type][direction > 0 ? validChars[type].length - 1 : 0];
			}

			if (direction > 0) {
				newChar = validMap[type][oldChar];
			} else {
				newChar = validRevMap[type][oldChar];
			}
			if (newChar === undefined) {
				newChar = oldChar;
			}
			return newChar;
		}
	};
}());

function getNextPage(bRev) {
	var nextPageIndex = currPageIndex;
	do {
		if (!bRev) {
			if (++nextPageIndex >= pages.length) {
				nextPageIndex = 0;
			}
		} else {
			if (--nextPageIndex < 0) {
				nextPageIndex = pages.length - 1;
			}
		}
	} while (pages[nextPageIndex].hidden === "true" && !security.canSeeHidden());

	return pages[nextPageIndex].name;
}

function moveToField(name) {
	var vals, i;

	vals = navctx.active.xmlPage.getElementsByTagName('val');
	for (i = 0; i < vals.length; i++) {
		if (vals[i].getAttribute('id') === name) {
			G.nav.selectField(i);
			break;
		}
	}
}

function nextWritableField(startFieldIndex) {
	var cacheHit, oldFieldIndex, bFound, nrOfFields, i, xatSval, newElem, xatDis;

	cacheHit = navctx.active.fieldJumpCache[startFieldIndex];
	if (cacheHit !== undefined) {
		return cacheHit;
	}
	oldFieldIndex = startFieldIndex;
	bFound = false;
	nrOfFields = navctx.active.xmlPage.getElementsByTagName('val').length;
	for (i = 0; i < nrOfFields; i++) {
		if (++startFieldIndex >= nrOfFields) {
			startFieldIndex = 0;
		}

		if (navctx.active.xmlPage.getElementsByTagName('val')[startFieldIndex].parentNode.tagName === "lst" &&
				parseInt(navctx.active.xmlPage.getElementsByTagName('val')[startFieldIndex].parentNode.getAttribute("nr_of_items"), 10) > 0) {
			bFound = true;
			break;
		}

		xatSval = navctx.active.xmlPage.getElementsByTagName('val')[startFieldIndex].getAttribute('varw');
		if (xatSval === null) {
			xatSval = navctx.active.xmlPage.getElementsByTagName('val')[startFieldIndex].getAttribute('vare');
		}
		if (xatSval !== null) {
			// TODO Disabled checking takes quite a lot of time
			newElem = document.getElementById('ajax_' + navctx.active.xmlPage.getElementsByTagName('val')[startFieldIndex].getAttribute('id'));
			xatDis = "";
			if (newElem && newElem.firstChild) {
				xatDis = newElem.firstChild.className;
			}
			if (xatDis === null || xatDis.indexOf("disabled") === -1) {
				// Found writable value
				bFound = true;
				break;
			}
		}
	}

	if (!bFound) {
		startFieldIndex = null;
	}

	navctx.active.fieldJumpCache[oldFieldIndex] = startFieldIndex;

	return startFieldIndex;
}

function findPos(obj) {
	var curleft, curtop, fieldWidth, oObj;

	if (obj.absoluteX !== undefined) {
		return [obj.absoluteX, obj.absoluteY];
	}
	curleft = 0;
	curtop = 0;
	fieldWidth = obj.offsetWidth;
	oObj = obj;
	if (oObj.offsetParent) {
		do {
			curleft += oObj.offsetLeft;
			curtop += oObj.offsetTop;
		} while (oObj = oObj.offsetParent);

		obj.absoluteX = curleft;
		obj.absoluteY = curtop;
		return [obj.absoluteX, obj.absoluteY];
	}
}

function getFieldPosition(fieldIndex) {
	var node, xatId, elem, xy;

	node = navctx.active.xmlPage.getElementsByTagName('val')[fieldIndex];
	xatId = (node.parentNode.nodeName === 'lst') ? node.parentNode.getAttribute('id') : node.getAttribute('id');
	elem = document.getElementById('ajax_' + xatId);
	xy = findPos(elem);
	return [xy[0], xy[1], elem.offsetWidth, elem.offsetHeight];
}

function selectCurrentListItem() {
	var element, fun, tr, list;

	list = document.getElementById('ajax_' + navctx.active.currLst);
	
	element = navctx.active.xmlPage.getElementsByTagName('lst')[0]; // TODO Use 'lst' with 'currLst' id
	fun = element.getAttribute('vare');

	tr = list.selectedTr;
	eval(fun);
	return;
}

function findColumnDataById(row, id) {
	var testId, i, cols;

	cols = row.getElementsByTagName('td');
	for (i = 0; i < cols.length; i++) {
		testId = cols[i].firstChild.getAttribute('id');
		if (testId !== null && testId.match("^ajax_" + id + "[0-9]*")) {
			return cols[i].firstChild.firstChild.innerHTML;
		}
	}
	return null;
}

function gotoNode(tr) {
	// TODO Get information from better place
	var ip, name, no;

	ip = findColumnDataById(tr, 'disc_ip');
	name = findColumnDataById(tr, 'disc_name');
	no = findColumnDataById(tr, 'disc_address');

	if (name.replace(/\s*$/g, '').length === 0) {
		name = "&nbsp;";
	}
	currNodeName = name;

	if (ip === null || ip === "" || no === null || no === "") {
		return;
	}

	try {
		initMainCont("http://" + ip + "/unit/", true);
		controllerUnitPath = "http://" + ip + "/unit/";
	} catch (e) {
		//if (e.code == 1012 || e.code == 101 || e.name == "NS_ERROR_FAILURE") {
		initMainCont("engine/proxy.php?proxy_url=http://" + ip + "/unit/", true);
		controllerUnitPath = "engine/proxy.php?proxy_url=http://" + ip + "/unit/";
		//} else {
		//	document.getElementById('engine_nwstatus').innerHTML = getText("node_connect_problem");
		//	console.log("Cound not connect to node, problem: " + e);
		//}
	}
	updateHeader(no, name, ip);
}

function scrollList(id, dir, page) {
	var element, scrollStart, nrOfItems, rows, res, newPos;

	element = navctx.active.xmlPage.getElementsByTagName('lst')[0]; // TODO Use 'lst' with given id
	scrollStart = parseInt(element.getAttribute('scroll_start'), 10);
	nrOfItems = parseInt(element.getAttribute('nr_of_items'), 10);
	rows = element.getAttribute('rows');
	if (isNaN(scrollStart)) {
		scrollStart = 0;
	}

	res = true;
	newPos = Math.min(Math.max(0, nrOfItems - rows), Math.max(0, scrollStart + parseInt(dir, 10) * (page ? rows : 1)));
	if (newPos === scrollStart) {
		newPos = dir > 0 ? 0 : Math.max(0, nrOfItems - rows);
		res = false;
	}
	if (newPos !== scrollStart) {
		element.setAttribute('scroll_start', newPos);

		element.reloadLst();
	}

	return res;
}

function scrollTo(element, dir, pos) {
	var scrollStart, nrOfItems, rows, res, trOffset, nrOfRows, newScrollStart;

	scrollStart = parseInt(element.getAttribute('scroll_start'), 10);
	nrOfItems = parseInt(element.getAttribute('nr_of_items'), 10);
	rows = parseInt(element.getAttribute('rows'), 10);
	if (isNaN(scrollStart)) {
		scrollStart = 0;
	}
	res = true;
	trOffset = 0;
	nrOfRows = rows - trOffset;

	newScrollStart = scrollStart;
	if (pos < scrollStart) {
		newScrollStart = pos;
	} else if (pos >= (scrollStart + nrOfRows)) {
		newScrollStart = pos - nrOfRows + 1;
	}

	if (newScrollStart !== scrollStart) {
		element.setAttribute('scroll_start', newScrollStart);
		element.reloadLst();
	}

	return res;
}

var prevLstSelectTime = 0;
function selectInLst(direction, xatId, rRowNr) {
	var now, element, nrOfItems, list, rows, rowNr, trOffset, selectTr;

	now = new Date().getTime();
	if (now - 80 < prevLstSelectTime) {
		return;
	}

	prevLstSelectTime = now;

	element = navctx.active.xmlPage.getElementsByTagName('lst')[0]; // TODO Use 'lst' with given id
	nrOfItems = parseInt(element.getAttribute('nr_of_items'), 10);

	list = document.getElementById('ajax_' + xatId);
	rows = list.getElementsByTagName('tr');

	if (rRowNr !== undefined) {
		rowNr = rRowNr;
	}
	if (rowNr === undefined) {
		rowNr = list.selectedRowNumber;
	}
	trOffset = 1; // rows[0].firstChild?1:0;
	if (!rowNr) {
		rowNr = direction === 2 ? Math.min(nrOfItems, rows.length - 1) : trOffset;
	} else {
		switch (direction) {
		case 2: // up
			rowNr--;
			if (rowNr < trOffset) {
				if (rRowNr === undefined ? !scrollList(xatId, -1) : !scrollTo(xatId, -1, rowNr)) {
					G.nav.unmarkElement(list.selectedTr);
					if (!G.nav.moveToOtherField(direction)) {
						rowNr = Math.min(nrOfItems, rows.length - 1);
					} else {
						list.selectedRowNumber = null;
						list.selectedTr = null;
						return;
					}
				}	
				else {
					rowNr = trOffset;
				}
			}
			break;
		case 3: // down
			rowNr++;
			if (rowNr >= Math.min(rows.length, nrOfItems + trOffset)) {
				if (rRowNr === undefined ? !scrollList(xatId, 1) : !scrollTo(xatId, 1, rowNr)) {
					G.nav.unmarkElement(list.selectedTr);
					if (!G.nav.moveToOtherField(direction)) {
						rowNr = trOffset;
					} else {
						list.selectedRowNumber = null;
						list.selectedTr = null;
						return;
					}
				} else {
					rowNr = rows.length - 1;
				}
			}
			break;
		}
	}
	if (rowNr != list.selectedRowNumber) {
		selectTr = rows[rowNr];
		G.nav.unmarkElement(list.selectedTr);
		selectTr.style.outline = '1px solid';
		selectTr.style.backgroundColor = '#22FF99';
		list.selectedTr = selectTr;
		list.selectedRowNumber = rowNr;
	}
}

function selectItemInLst(xatId, itemNr) {
	var element, nrOfItems, list, rows, scrollStart, newRowNr, selectTr;

	element = navctx.active.xmlPage.getElementsByTagName('lst')[0]; // TODO Use 'lst' with given id
	nrOfItems = parseInt(element.getAttribute('nr_of_items'), 10);

	if (itemNr < 0 || itemNr > nrOfItems) {
		return;
	}

	list = document.getElementById('ajax_' + xatId);
	rows = list.getElementsByTagName('tr');


    scrollTo(element, -1, itemNr);
	scrollStart = parseInt(element.getAttribute('scroll_start'), 10);
	if (isNaN(scrollStart)) {
		scrollStart = 0;
	}
	newRowNr = itemNr - scrollStart + 1;

	if (newRowNr !== list.selectedRowNumber) {
		selectTr = rows[newRowNr];
		G.nav.unmarkElement(list.selectedTr);
		selectTr.style.outline = '1px solid';
		selectTr.style.backgroundColor = '#22FF99';
		list.selectedTr = selectTr;
		list.selectedRowNumber = newRowNr;
	}
}


function keyCheckEdt(e, type, element) {
	var res, keyId, direction, fixed, width, epos, spos, value, sel, pos, ch, oLen, selWidth, insert, sel2;

	if (!!e) {
		e.handeled = true;
	}
	element.readOnly = false;
	res = true;
	keyId = (window.event) ? event.keyCode : e.which;
	direction = -1;
	fixed = element.parentNode.getAttribute("containsFixed") === "true";
	switch (keyId) {
		/*
		 // TODO To get this to work, padding must be added and the cursor must not disappear
		case K_PGDOWN:
			direction = 1;
		case K_PGUP:
			direction *= -1;
			console.log("PG: " + type);
			if (type == 'int') {
				var value = element.value;
				var valueI = parseInt(value,10);
				console.log("Old value: " + valueI)
				valueI += direction;
				element.value = valueI;
				console.log("New value: " + valueI)
			}
			break;
			*/
	case 48:
	case 49:
	case 50:
	case 51:
	case 52:
	case 53:
	case 54:
	case 55:
	case 56:
	case 57:
	case K_FUNCTION:
		if (type !== 'int' && keyId === K_FUNCTION) {
			res = false;
			break;
		}
		ch = (keyId === K_FUNCTION) ? "." : String.fromCharCode(keyId);
		if (document.selection) {
			sel = document.selection.createRange();
			width = element.value.length;
			if (sel.text.length === width) {
				element.value = padStr("", (type === 'str' ? ' ' : '0'), width - 1) + ch;
				sel.moveStart("character", width);
			} else {
				if (sel.text.length === 0) {
					element.value = element.value.substring(1) + ch;
					sel.moveStart("character", width);
				} else {
					if (fixed && !characters.isValid(sel.text.charAt(0), type)) {
						res = false;
						break;
					}
					sel.text = padStr(ch, (type === 'str' ? ' ' : '0'), sel.text.length);
					sel.moveEnd("character", 1);
					if (fixed && sel.text.length === 0) {
						sel.moveStart("character", -1);
					}
					// TODO Code for skipping invalid charactes needed
				}
			}
			sel.select();
		} else {
			spos = element.selectionStart;
			epos = element.selectionEnd;
			value = element.value;
			width = value.length;
			if (epos - spos === width) { // The whole field is selected
				element.value = padStr("", (type === 'str' ? ' ' : '0'), width - 1) + ch;
				spos = width;
			} else if ((epos === spos) && (spos === width)) { // Insert mode
				element.value = value.substring(1) + ch;
			} else { // One characted selected
				if (fixed && !characters.isValid(value.charAt(spos), type)) {
					res = false;
					break;
				}
				value = value.substring(0, spos) + ch + value.substring(epos);
				element.value = padStr(value, (type === 'str' ? ' ' : '0'), width);
			}
			if (!((fixed) && (epos === width)) && (spos < width)) {
				spos++;
			}

			if (spos !== width && !characters.isValid(value.charAt(spos), type)) {
				spos++;
			}
			element.setSelectionRange(spos, spos + (spos === width ? 0 : 1));
		}
		res = false;
		break;
	case K_DOWN:
		direction = 1;
	case K_UP:
		direction *= -1;

		if (document.selection) {
			sel = document.selection.createRange();

			if (sel.text.length === 0) {
				element.value = element.value.substring(1) + characters.next(-1, type, direction); 
				sel.moveStart("character", element.value.length - 1);
				sel.moveEnd("character", 1);
			} else {
				if (sel.text.length > 1) {
					sel.moveEnd("character", sel.text.length);
					sel.moveStart("character", sel.text.length - 1);
				}
				sel.text = characters.next(sel.text.charAt(0), type, direction);
				sel.moveStart("character", -1);
			}
			sel.select();
		} else {
			spos = element.selectionStart;
			epos = element.selectionEnd;
			width = element.value.length;
			value = element.value;
			if ((epos === spos) && (epos === width)) {
				value = value.substring(1) + characters.next(-1, type, direction);
				spos--;
			} else {
				if (epos - spos !== 1) {
					if (spos === 0) {
						epos = Math.min(width, epos + 1);
						spos = Math.min(width, epos - 1);
					} else {
						spos = Math.max(0, spos - 1);
						epos = Math.min(width, spos + 1);
					}
				} 
				value = value.substring(0, spos) + characters.next(value.charAt(spos), type, direction) + value.substring(epos);
			}
			element.value = value;
			element.setSelectionRange(spos, epos);
		}
		res = false;
		break;
	case K_LEFT:
		if (document.selection) {
			// TODO Code for skipping invalid charactes needed
			sel = document.selection.createRange();
			oLen = sel.text.length;
			width = element.value.length;
			sel.moveStart("character", -1);
			if (sel.text.length > 1) {
				sel.moveEnd("character", -oLen + (width === sel.text.length ? 1 : 0));
			}
			sel.select();
		} else {
			pos = element.selectionStart;
			if (pos > 0) {
				pos--;
			}
			if (type !== 'int' && pos > 0 && !characters.isValid(element.value.charAt(pos), type)) {
				pos--;
			}
			element.setSelectionRange(pos, pos + 1);
		}
		res = false;
		break;
	case K_RIGHT:	
		if (document.selection) {
			// TODO Code for skipping invalid charactes needed
			sel = document.selection.createRange();
			sel.moveStart("character", sel.text.length);
			sel.moveEnd("character", 1);
			if (fixed && sel.text.length === 0) {
				sel.moveStart("character", -1);
			}
			sel.select();
		} else {
			pos = element.selectionStart;
			width = element.value.length;
			if (fixed && (element.selectionEnd === width)) {
				res = false;
				break;
			}
			if (element.selectionEnd - pos === width) {
				pos = width;
			}
			if (pos < width) {
				pos++;
			}
			if (type !== 'int' && pos !== width && !characters.isValid(element.value.charAt(pos), type)) {
				pos++;
			}
			element.setSelectionRange(pos, pos + (pos === width ? 0 : 1));
		}
		res = false;
		break;
	case K_ENTER:
		onChangeVal(element, 0); // TODO Fix type argument
		res = false;
		break;
	case K_DEL:
		if (fixed) {
			res = false;
			break;
		}
		if (document.selection) {
			sel = document.selection.createRange();
			width = element.value.length;
			if (sel.text.length === 0) {
				sel.moveStart("character", -1);
				insert = true;
			}
			if (sel.text.length === width) {
				insert = true;
			}
			selWidth = sel.text.length;
			sel.moveStart("character", -width);
			pos = sel.text.length;
			sel2 = sel.duplicate();
			sel.moveEnd("character", -selWidth);
			sel2.text = padStr(sel.text, (type === 'str' ? ' ' : '0'), sel2.text.length);
			if (insert) {
				sel.moveStart("character", width);
			} else {
				sel.moveStart("character", pos - 1);
				sel.moveEnd("character", 1);
			}
			sel.select();
		} else {
			spos = element.selectionStart;
			epos = element.selectionEnd;
			width = element.value.length;
			value = element.value;
			value = value.substring(0, spos === width ? epos - 1 : spos) + value.substring(epos);
			element.value = padStr(value, (type === 'str' ? ' ' : '0'), width);
			if (epos - spos === width) {
				element.setSelectionRange(width, width);
			} else {
				element.setSelectionRange(spos, spos + 1);
			}
		}
		res = false;
		break;
	case K_CANCEL:
		onBlurVal(element, 0);
		break;
	default:
	}
	element.readOnly = true;
	return res;
}

function keyCheckEdtStr(e) {
	return keyCheckEdt(e, 'str', this);
}
function keyCheckEdtDte(e) {
	return keyCheckEdt(e, 'dte', this);
}
function keyCheckEdtInt(e) {
	return keyCheckEdt(e, 'int', this);
}

var MAGIC_DELTA = 99999999;
var etu_nav = function () {
	var disabledKeyPressHook, keyHooks;

	disabledKeyPressHook = null;
	keyHooks = {"str": keyCheckEdtStr, "int": keyCheckEdtInt, "dte": keyCheckEdtDte, "tme": keyCheckEdtDte, "ip": keyCheckEdtDte};

	keyCheck.subscribe(sec_ping);
	keyCheck.subscribe(etu_display_ping);
	keyCheckPopup.subscribe(sec_ping);
	keyCheckPopup.subscribe(etu_display_ping);

	return {
		navPageInit: function (xmlPage) {
			var nav, init;

			nav = xmlPage.getElementsByTagName('nav');
			if (nav.length === 1) {
				init = nav[0].getAttribute("initial");

				moveToField(init);
			} else {
				G.nav.moveToOtherField(3);
			}
			if (nav.length === 1 && nav[0].getAttribute("active") === 'true') {
				G.nav.activateCurrentField();
			}
		},
		moveToOtherField: function (direction) {
			var nrOfFields, xatId, elem, fieldIndex, currxy, closest, closestdelta, currx, curry, xyw, currwidth, size, i, delta, list;

			// direction: 0 == left, 1 == right, 2==up, 3==down
			nrOfFields = navctx.active.xmlPage.getElementsByTagName('val').length;

			if (navctx.active.currFieldIndex === null) {
				navctx.active.currFieldIndex = -1;
			}

			if (navctx.active.currFieldIndex !== -1) {
				xatId = navctx.active.xmlPage.getElementsByTagName('val')[navctx.active.currFieldIndex].getAttribute('id');
				elem = document.getElementById('ajax_' + xatId);
			}

			fieldIndex = navctx.active.currFieldIndex;
			if (navctx.active.currFieldIndex === -1) {
				size = getPageSize();
				currx = size[0] / 3;
				currwidth = 0;
				curry = 0;
				direction = 3; // Get top left field
			} else {
				currxy = getFieldPosition(navctx.active.currFieldIndex);
				currx = currxy[0];
				curry = currxy[1];
				currwidth = currxy[2];
			}

			closest = -1;
			closestdelta = MAGIC_DELTA;
			for (i = 0; i < nrOfFields; i++) {
				fieldIndex = nextWritableField(fieldIndex);
				if (fieldIndex === null) {
					break;
				}
				xyw = getFieldPosition(fieldIndex);

				delta = distance(currx, curry, xyw[0], xyw[1], currwidth, xyw[2], direction);
				if ((delta > 0) && (delta < closestdelta)) {
					closestdelta = delta;
					closest = fieldIndex;
				}
			}

			if (closest !== -1 && closestdelta !== MAGIC_DELTA) {
				if (elem) {
					G.nav.unmarkElement(elem);
				}

				if (navctx.active.xmlPage.getElementsByTagName('val')[closest].parentNode.nodeName === 'lst') {
					navctx.active.currLst = navctx.active.xmlPage.getElementsByTagName('val')[closest].parentNode.getAttribute('id');
					navctx.active.currFieldIndex = closest;

					list = document.getElementById('ajax_' + navctx.active.currLst);
					list.selectedTr = null;
					selectInLst(direction, navctx.active.currLst);
				} else {
					navctx.active.currLst = null;
					G.nav.selectField(closest);
				}
				return true;
			}

			return false;
		},

		selectField: function(field) {
			navctx.active.currFieldIndex = field;
			G.nav.markSelectedField();
		},
		markSelectedField: function () {
			var xatId, elem, tagVal;

			if (navctx.active.currFieldIndex === -1 || typeof navctx.active.xmlPage.getElementsByTagName('val')[navctx.active.currFieldIndex] !== 'object') {
				return;
			}
			tagVal = navctx.active.xmlPage.getElementsByTagName('val')[navctx.active.currFieldIndex];
			xatId = tagVal.getAttribute('id');
			elem = document.getElementById('ajax_' + xatId);
			if (elem) {
				//elem.focus();
				if (elem.firstChild && elem.firstChild.type === "button") {
					elem = elem.firstChild;
				}
				if (tagVal.getAttribute("type") === "tog") {
					elem.style.outline = '2px solid black';
				} else {
					elem.style.backgroundColor = '#22FF99';
					elem.style.outline = '1px solid black';
				}
			}
		},

		activateCurrentField: function () {
			var xatId, xatFType, elem, tagVal;

			if (navctx.active.currFieldIndex !== -1) {
				tagVal = navctx.active.xmlPage.getElementsByTagName('val')[navctx.active.currFieldIndex];
				xatId = tagVal.getAttribute('id');
				xatFType = tagVal.getAttribute('type');
				elem = document.getElementById('ajax_' + xatId);
				if (elem) {
					if (!hasClass(elem.firstChild, /val_rw/)) {
						return;
					}
					if (!!elem.getAttribute("lastupdatetime") &&  (new Date().getTime() < elem.getAttribute("lastupdatetime"))) {
						return;
					}
					G.nav.unmarkElement(elem);
					switch (xatFType) {
					case 'drp':
					case 'edt':
					case 'pwd':
						onClickVal(elem.firstChild, 0, false); // TODO First child always ok?
						break;
					case 'btn':
						onClickVal(elem.firstChild, 1, false); // TODO First child always ok?
						break;
					case 'tog':
						onClickVal(elem.firstChild, 2, false); // TODO First child always ok?
						break;
					}
					//onClickTog(elem)
					//onClickBtn(elem}
				}
			}
		},

		focusField: function (element, type) {
			element.onkeypress = keyHooks[type];
			element.select();
		},
		focusPopup: function () {
			document.onkeypress = keyCheckPopup;
		},
		focusPage: function() {
			document.onkeypress = keyCheck;
		},
		disableNavigation: function () {
			disabledKeyPressHook = document.onkeypress;
			document.onkeypress = null;
		},
		enableNavigation: function () {
			document.onkeypress = disabledKeyPressHook;
		},
		unmarkElement: function (elem) {
			if (!elem) {
				return;
			}
			if (elem.firstChild && elem.firstChild.type === "button") {
				elem = elem.firstChild;
			}
			elem.style.outline = '';
			if (!hasClass(elem, /val_tog/)) {
				elem.style.backgroundColor = '';
			}
		}
	};
};

var cpt_nav = function () {
	var t = {
		markSelectedField: function () {
		},
		selectField: function(field) {
			navctx.active.currFieldIndex = field;
		},
		focusField: function (element, type) {
			var ele = element;
			element.onkeyup = function (e) {
				// TODO Only needed for IE6, but will be used in Safari(and others?)
				var keyId = (window.event) ? event.keyCode : e.keyCode;
				if (window.event &&  keyId === 13) { // Enter
					//ele.blur();
					onChangeVal(ele, 0);
				} else if (keyId === 27) { // Esc
					onBlurVal(ele, 0);
				}
			};
		},
		focusPage: function() {
		},
		focusPopup: function () {
		},
		disableNavigation: function () {
		},
		enableNavigation: function () {
		},
		navPageInit: function (xmlPage) {
			var nav, init, xatId, xatFType, elem, fieldNr, tagVal;

			nav = xmlPage.getElementsByTagName('nav');

			if ((nav.length === 1) && (nav[0].getAttribute("active") === 'true')) {
				init = nav[0].getAttribute("initial");

				fieldNr = -1;
				vals = xmlPage.getElementsByTagName('val');
				for (i = 0; i < vals.length; i++) {
					if (vals[i].getAttribute('id') === init) {
						fieldNr = i;
						break;
					}
				}

				tagVal = xmlPage.getElementsByTagName('val')[fieldNr];
				xatFType = tagVal.getAttribute('type');
				elem = document.getElementById('ajax_' + init);
				if (elem) {
					if (!!elem.getAttribute("lastupdatetime") &&  (new Date().getTime() < elem.getAttribute("lastupdatetime"))) {
						return;
					}
					switch (xatFType) {
						case 'drp':
						case 'edt':
						case 'pwd':
							onClickVal(elem.firstChild, 0, true); // TODO First child always ok?
							break;
						case 'btn':
							onClickVal(elem.firstChild, 1, true); // TODO First child always ok?
							break;
						case 'tog':
							onClickVal(elem.firstChild, 2, true); // TODO First child always ok?
							break;
					}
				}
			}
		},
		unmarkElement: function (elem) {
		},
		moveToOtherField: function (direction) {
		}
	};
	return t;
};

function getPageSize() {
	if (navigator.appName.indexOf("Microsoft") !== -1) {
		return [document.body.offsetWidth, document.body.offsetHeight];
	} else {
		return [window.innerWidth, window.innerHeight];
	}
}

var maxSize = null;
var size = null;

function distance(x1, y1, x2, y2, currwidth, width, direction) {
	var delta, deltax, deltay, deltaxl, deltaxr, deltaxlr, deltaxrl;

	if (!maxSize) {
		size = getPageSize();
		maxSize = Math.max(size[0], size[1]);
	}
	delta = MAGIC_DELTA;
	deltax = 0;
	deltay = 0;
	switch (direction) {
	case 0: // Left
		deltax = 2 * (x1 - x2);
	case 1: // Right
		deltax += (x2 - x1);
		deltay = (y1 - y2);
		if (deltax !== 0) {
			if (deltax < 0) {
				deltax += size[0];
			}
			delta = Math.atan2(Math.abs(deltay), Math.abs(deltax)) * 10000 + deltax;
		}
		break;
	case 2: // Up
		deltay = 2 * (y1 - y2);
	case 3: // Down
		deltay += (y2 - y1);
		deltaxl = Math.abs(x1 - x2);
		deltaxr = Math.abs(x1 + currwidth - x2 - width);
		deltaxlr = Math.abs(x1 - x2 - width);
		deltaxrl = Math.abs(x1 + currwidth - x2);
		deltax = Math.min(deltaxrl, Math.min(deltaxlr, Math.min(deltaxl, deltaxr)));
		if (deltax < 3) {
			deltax = 0;
		}

		if (deltay < 0) {
			deltay += size[1];
		}

		if (deltay !== 0) {
			delta = Math.sqrt(deltax * deltax + deltay * deltay);
		}
		break;
	}
	return delta;
}

function keyCheckCommon(keyId) {
	switch (keyId) {
	case 67: //
	case K_ENTER:
		if (navctx.active.currLst === null) {
			G.nav.activateCurrentField();
		} else {
			selectCurrentListItem();
		}
		break;
	case 72: // h (left)
	case K_LEFT:
		if (navctx.active.currLst === null) {
			G.nav.moveToOtherField(0);
		}
		break;
	case 76: // l (right)
	case K_RIGHT:
		if (navctx.active.currLst === null) {
			G.nav.moveToOtherField(1);
		}
		break;
	case 75: // k (up)
	case K_UP:
		if (navctx.active.currLst === null) {
			G.nav.moveToOtherField(2);
		} else {
			selectInLst(2, navctx.active.currLst);
		}
		break;
	case 74: // j (down)
	case K_DOWN:
		if (navctx.active.currLst === null) {
			G.nav.moveToOtherField(3);
		} else {
			selectInLst(3, navctx.active.currLst);
		}
		break;
	case K_PGUP:
		if (navctx.active.currLst) {
			scrollList(navctx.active.currLst, -1, true);
		}
		break;
	case K_PGDOWN:
		if (navctx.active.currLst) {
			scrollList(navctx.active.currLst, 1, true);
		}
		break;
	case 48:
	case 49:
	case 50:
	case 51:
	case 52:
	case 53:
	case 54:
	case 55:
	case 56:
	case 57:
		if (navctx.active.currLst) {
			numJumpInLst(navctx.active.currLst, keyId);
		}
		break;
	default:
	}
}

function numJumpInLst(list, ch) {
	var element, nrOfItems, enteredValueElement, val, showValue;

	element = navctx.active.xmlPage.getElementsByTagName('lst')[0]; // TODO Use 'lst' with given id
	nrOfItems = parseInt(element.getAttribute('nr_of_items'), 10);
	if (navctx.active.blankValTimer) {
		clearTimeout(navctx.active.blankValTimer);
	}

	navctx.active.enteredValue += (ch - 48);

	enteredValueElement  = document.getElementById('engine_popup_entered_value') ? document.getElementById('engine_popup_entered_value') : document.getElementById('engine_entered_value');
	val = parseInt(navctx.active.enteredValue, 10);
	showValue = navctx.active.enteredValue;
	if ((val === 0 ? 1 : val) * Math.pow(10, (navctx.active.enteredValue).length) > nrOfItems) {
		if (val <= nrOfItems) {
			selectItemInLst(list, val - 1);
		}
		navctx.active.enteredValue = "";
		navctx.active.blankValTimer = setTimeout(function () {
				enteredValueElement.innerHTML = "";
			}, 800);
	} else {
		if (showValue !== "") {
			showValue += "..";
		}
	}
	enteredValueElement.innerHTML = showValue;
}

function keyCheckPopup(e) {
	var keyId;

	keyCheckPopup.notify();
	if (noSelect) {
		return;
	}
	if (!!e && e.handeled) {
		return;
	}
	keyId = (window.event) ? event.keyCode : e.which;
	if (keyId === 0) {
		keyId = e.keyCode;
	}
	if (navctx.active.keyHitHook) {
		navctx.active.keyHitHook();
	}
	switch (keyId) {
	case 112:  // p (help)
	case 80: // P (help)
	case K_CANCEL:
	case 77: // m (menu)
	case 109:
		updateValueSync("cancel", "1", document.getElementById("cancel"), true, 1, -1, null);
		break;
	default:
		keyCheckCommon(keyId);
	}
}


var displayTimer = null;
function etu_display_ping() {
	if (displayTimer === null) {
		sendLocalValueSync("engine/w_backlight.cgi",
				(parseInt(configuration.backlight_active, 10) * 255 / 100).toFixed(0));
	} else {
		clearTimeout(displayTimer);
	}
	displayTimer = setTimeout(
			function () {
				displayTimer = null;
				sendLocalValueSync("engine/w_backlight.cgi",
					(parseInt(configuration.backlight_idle, 10) * 255 / 100).toFixed(0));
			}, DISPLAY_IDLE_TIME);
}


function keyCheckDrp(e) {
	var keyId;

	if (e) {
		e.handeled = true;
	}
	keyId = (window.event) ? event.keyCode : e.which;
	switch (keyId) {
	case K_DOWN:
		if (this.selectedIndex < (this.length - 1)) {
			this.selectedIndex++;
		} else {
			this.selectedIndex = 0;
		}
		break;
	case K_UP:
		if (this.selectedIndex > 0) {
			this.selectedIndex--;
		}
		else {
			this.selectedIndex = this.length - 1;
		}
		break;
	case K_ENTER:
		onChangeVal(this, 0);
		break;
	case K_CANCEL:
		onBlurVal(this, 0);
		break;
	}
}

function keyCheck(e) {
	var keyId;

	keyCheck.notify();
	if (noSelect) {
		return;
	}
	if (!!e && e.handeled) {
		return;
	}
	keyId = (window.event) ? event.keyCode : e.which;
	if (keyId === 0) {
		keyId = e.keyCode;
	}

	switch (keyId) {
	case K_CANCEL:
		pages = [];
		ip = null;
		initMainCont('engine/', false); // TODO Not good
		currNodeName = "";
		updateHeader("", "", null);
		break;
	case 77: // m (menu)
	case 109:
		if (document.getElementById("menu").style.visibility === 'visible') {
			closePopup("menu");
		} else {
			showPopupMenu();
		}
		break;
	case 80: // p (help)
	case 112:
		if (document.getElementById("help").style.visibility === 'visible') {
			closePopup("help");
		} else {
			showPopupHelp();
		}
		break;
	case 83: // s (next page)
	case 115:
		if (pages.length > 1) {
			gotoPage(getNextPage(), unitPath);
		}
		break;
	case 87: // w (previous page)
	case 119:
		if (pages.length > 1) {
			gotoPage(getNextPage(true), unitPath);
		}
		break;
	default:
		keyCheckCommon(keyId);
	}
}

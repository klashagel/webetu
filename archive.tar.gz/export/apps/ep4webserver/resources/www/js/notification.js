Function.prototype.subscribe = function (callback) {
	// TODO See if it possible to add so that "notify" is automatically invoked when "this" is executed
	if (typeof this.subscribers !== 'object') {
		this.subscribers = {};
	}
	this.subscribers[callback] = callback;
};
Function.prototype.unsubscribe = function (callback) {
	if (typeof this.subscribers !== 'object') {
		this.subscribers = {};
	}
	delete this.subscribers[callback];
};
Function.prototype.notify = function () {
	var m;

	if (typeof this.subscribers !== 'object') {
		this.subscribers = {};
	}
	for (m in this.subscribers) {
		if (typeof this.subscribers[m] === 'function') {
			this.subscribers[m].apply(null, arguments);
		}
	}
};

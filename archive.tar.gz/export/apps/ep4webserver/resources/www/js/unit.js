/* Alstom web package (c) 2008-2009
 * Author: Anders Risberg, anders@arisberg.com
 *		 John Kjellberg, john.kjellberg@power.alstom.com
 */
/*global G getPageSize restoreContext pausePollers updateValueSync pageLoader isOnController conf  pages configuration listFiles sendLocalValueSync translationMap localisationLoader controllerUnitPath engineTranslationMap security helppages initMainCont updateHeader showLoginPopup navctx gotoPage window ip Font jsGraphics updateVariable i18n keyCheckDrp characters */

/*
document.write('<script type="text/javascript" src="http://getfirebug.com/releases/lite/1.2/firebug-lite-compressed.js"></script>');
*/


var popupview = null;
var noSelect = false;
var noSelect = false;
var ie = window.document.all && !window.opera;
var updateTime = 0;
var hideSeries1 = 1;
var hideSeries2 = 1;
var hideSeries3 = 1;
var hideSeries4 = 1;
var hideSeries5 = 1;
var hideSeries6 = 1;

var redrawGraph = false;


if (console == undefined) {
	var console = {log: function () {} };
}


document.write('<script type="text/javascript" src="js/i18n.js"></script>');
document.write('<script type="text/javascript" src="js/notification.js"></script>');
document.write('<script type="text/javascript" src="js/view.js"></script>');
document.write('<script type="text/javascript" src="js/ajax.js"></script>');
document.write('<script type="text/javascript" src="js/nav.js"></script>');
document.write('<script type="text/javascript" src="js/sec.js"></script>');
document.write('<script type="text/javascript" src="js/wz_jsgraphics.js"></script>');

document.write('<script type="text/javascript" src="js/excanvas.js"></script>'); //MW // for IE
document.write('<script type="text/javascript" src="js/dygraph-combined.js"></script>'); //MW
//document.write('<script type="text/javascript" src="js/progressbar.js"></script>'); //MW


// Initialize unit-part
function unitInit() {
	noSelect = false;
}

function closePopup(div) {
	var unsub, obj;

	document.getElementById("overlay").style.visibility = 'hidden';
	obj = document.getElementById(div);
	obj.style.visibility = 'hidden';

	popupview.stop();
	popupview = null;

	obj.innerHTML = "";
	updateValueSync = updateValueSyncUnit;
	navctx.pop();
	pausePollers(false);
}

function showPopup(fname, values, callbacks, div, postLoadHook, defField) {
	var lDiv, lDivElement, exemap, pageSize;

	pausePollers(true);
	navctx.createNewAndActivate();
	lDiv = div;
	exemap = callbacks;
	pageDataUnsubscriber = [];

	if (!lDiv) { 
		lDiv = 'popup'; 
	}

	updateValueSync = function (wrtFileName, value, element, isBitvalue, type, xatSize, tagName) {
		
		if (type !== 1) { // Not button
			element.innerHTML = "<label class='val_val val_rw' onclick='onClickVal(this," + type + ",true)'>" + element.getAttribute('lastvalstring') + "</label>";
			element.setAttribute("lastupdatetime", new Date().getTime());
			element.setAttribute("lastval", value);
		}
		if (element) {
			element.setAttribute("dirty", "true");
		}

		if (exemap && exemap[wrtFileName]) {
			if (exemap[wrtFileName][0] === null || exemap[wrtFileName][0]()) {
				closePopup(lDiv);
				if (exemap[wrtFileName][1]) { 
					exemap[wrtFileName][1](); 
				}
				G.nav.markSelectedField();
			}
		}
	};

	popupview = pageview(lDiv, "engine/");
	popupview.load(fname);
	popupview.start();

	G.nav.focusPopup();

	if (postLoadHook) { 
		postLoadHook(); 
	}

	lDivElement = document.getElementById(lDiv);

	pageSize = getPageSize();
	lDivElement.style.left = (pageSize[0] - lDivElement.offsetWidth) / 2 + 'px';
	lDivElement.style.top = (pageSize[1] - lDivElement.offsetHeight) / 2 + 'px';

	document.getElementById("overlay").style.visibility = 'visible';
	lDivElement.style.visibility = 'visible';

	if (values) { 
		popupview.handleData(values, new Date().getTime()); 
	}
}

function populateVersion(id) {
	currpageview.handleData(
			[{'id': id, 'type': 'str', 'value': conf[isOnController].version}],
			new Date().getTime());
}

function populateLanguageVal(view, valname, controller) {
	var vars, optds, optdv, languages, item, tagVal;

	tagVal = view.getValTagById(valname);

	optds = "";
	optdv = "";
	languages = conf[controller].languages;
	for (item in languages) {
		if (typeof item === 'string') {
			if (optds.length !== 0) {
				optds += ",";
					}
			if (optdv.length !== 0) { 
				optdv += ","; 
			}
			optds += i18n.getText(item);
			optdv += item;
		}
	}
	tagVal.setAttribute("optds", optds);
	tagVal.setAttribute("optdv", optdv);
}

function populateConfig() {
	var vars, optds, optdv, i, item;

	vars = navctx.active.xmlPage.getElementsByTagName('val');

	populateLanguageVal(popupview, "conf_etu_language", false);

	if (isOnController) {
		populateLanguageVal(popupview, "conf_controller_language", true);
	} else {
		tagVal = popupview.getValTagById("conf_controller_language");

		tagVal.setAttribute("optds", configuration.controller_language);
		tagVal.setAttribute("optdv", configuration.controller_language);
		tagVal.setAttribute("optdd", "true");
	}

	popupview.handleData(
		[
			{'id': 'conf_backlight_active', 'type': 'int', 'value': parseInt(configuration.backlight_active, 10)},
			{'id': 'conf_backlight_idle', 'type': 'int', 'value': parseInt(configuration.backlight_idle, 10)},
			{'id': 'conf_etu_language', 'type': 'str', 'value': configuration.etu_language},
			{'id': 'conf_controller_language', 'type': 'str', 'value': configuration.controller_language},
			{'id': 'conf_set_nw', 'type': 'int', 'value': 1}
		], new Date().getTime());
}

function populateInformation() {
	popupview.handleData(
		[
			{'id': 'information_etu_application_version', 'type': 'str', 'value': conf[false].version}
		], new Date().getTime());
}

function populateApplication() {
	popupview.handleData(
		[
			{'id': 'information_etu_application_version', 'type': 'str', 'value': conf[false].version},
			{'id': 'ok', 'type': 'int', 'value': 0},
			{'id': 'cancel', 'type': 'int', 'value': 1},
			{'id': 'file_list', 'type': 'str', 'value': "" },
			{'id': 'application_file_name', 'type': 'str', 'value': "" }
		], new Date().getTime());
	listFiles('application_dir');
}

function populatePlatform() {
	popupview.handleData(
		[
			{'id': 'information_etu_platform_version', 'type': 'str', 'value': conf[false].version},
			{'id': 'ok', 'type': 'int', 'value': 0},
			{'id': 'cancel', 'type': 'int', 'value': 1},
			{'id': 'file_list', 'type': 'str', 'value': "" },
			{'id': 'platform_file_name', 'type': 'str', 'value': "" }
		], new Date().getTime());
	listFiles('platform_dir');
}

function setBacklight(active) {
	var backlight_element, value, intvalue;

	backlight_element = document.getElementById(active ? "ajax_conf_backlight_active" : "ajax_conf_backlight_idle");
	value = backlight_element.getAttribute('lastval');

	intvalue = parseInt(value, 10);
	if (intvalue > 100) { 
		intvalue = 100; 
	}
	configuration[active ? "backlight_active" : "backlight_idle"] = ("" + intvalue);

	document.cookie = (active ? "backlight_active=" : "backlight_idle=") + intvalue + "; expires=31-Dec-2037 23:59:59 GMT";

	if (active) {
		sendLocalValueSync("engine/w_backlight.cgi", (intvalue * 255 / 100).toFixed(0));
	}
	populateConfig();
}

function setNwConfig() {
	var netmask, dhcp, gateway, responseText, xmlHttp, fname, element, target;

	ip = document.getElementById("ajax_conf_ip").getAttribute('lastval');
	netmask = document.getElementById("ajax_conf_netmask").getAttribute('lastval');
	dhcp = document.getElementById("ajax_conf_dhcp").getAttribute('lastval');
	gateway = document.getElementById("ajax_conf_gateway").getAttribute('lastval');

	ip = convertValueForWriting(ip, "ip", 16);
	netmask = convertValueForWriting(netmask, "ip", 16);
	gateway = convertValueForWriting(gateway, "ip", 16);

	// TOOD Error checking so that error text isn't shown
	responseText = null;
	xmlHttp = new XMLHttpRequest();
	fname = 'engine/network.php?ip=' + ip + '&netmask=' + netmask + '&dhcp=' + dhcp + '&gateway=' + gateway; // +'&'+new Date().getTime();
	xmlHttp.open("GET", fname, false);
	element = document.getElementById("hb");
	if (element) { 
		element.style.visibility = "visible"; 
	}
	xmlHttp.onreadystatechange = function () {
		if (this.readyState === XMLHttpRequest.DONE) {
			responseText = this.responseText;
			if (element) { 
				element.style.visibility = "hidden"; 
			}
		}
	};
	xmlHttp.send(null);

	popupview.handleData(
		[
			{'id': 'conf_set_nw', 'type': 'int', 'value': 1}
		], new Date().getTime());

	target = document.getElementById("popup");
	popupview.start();

	return false;
}

function switchCptLanguage(val) {
	var tmpXmlPage;

	configuration.saved_controller_language = configuration.controller_language = val;
	document.cookie = "controller_language=" + val + "; expires=31-Dec-2037 23:59:59 GMT";

	translationMap = [];
	localisationLoader("unit/res", val, translationMap);

	engineTranslationMap = {};
	localisationLoader("engine/res", val, engineTranslationMap);

	cptview.reload();
	cptview.start();

	tmpXmlPage = navctx.active.xmlPage;
	mainview.reload();
	navctx.active.xmlPage = tmpXmlPage;
	checkLogoutTimer();
}

function switchLanguage(val, controller) {
	var tmpXmlPage;

	if (controller) {
		configuration.saved_controller_language = configuration.controller_language = val;
		document.cookie = "controller_language=" + val + "; expires=31-Dec-2037 23:59:59 GMT";

		translationMap = [];
		localisationLoader(controllerUnitPath + "res", val, translationMap);

	} else {
		configuration.etu_language = val;
		document.cookie = "etu_language=" + val + "; expires=31-Dec-2037 23:59:59 GMT";

		engineTranslationMap = {};
		localisationLoader("engine/res", val, engineTranslationMap);
		popupview.stop();
		popupview.reload();
		popupview.start();
		G.nav.markSelectedField();

		updateHeader("", "", null);
		checkLogoutTimer();
	}

	if (controller || !isOnController) { // Either on discovery page and ETU langugage is changed, or on controller and controller language changed
		tmpXmlPage = navctx.active.xmlPage;
		mainview.reload();
		navctx.active.xmlPage = tmpXmlPage;
	}
}


var menuPageItems = {}; 
function showPopupMenu() {
	var menuItems, text, go_to_page, i, config, node_list, login, logout;

	menuItems = "";
	go_to_page = i18n.getText("go_to_page");
	for (i = 0; pages && i < pages.length;  i++) {
		// TODO Exclude current page
		if (pages[i].title !== null && (pages[i].hidden !== "true" || security.canSeeHidden())) {
			menuItems += go_to_page + ' ' + i18n.getText(pages[i].title) + ",";
			menuPageItems[go_to_page + ' ' + i18n.getText(pages[i].title)] = pages[i].name;
		}
	}

	if (isOnController) { // TODO Hack
		node_list = i18n.getText("node_list");
		menuItems += node_list + ',';
		menuPageItems[node_list] = "discovery";

		if (!!conf[isOnController].canstoreretrieve) {
			login = i18n.getText('store_settings');
			menuItems += login + ",";
			menuPageItems[login] = "store_settings";

			login = i18n.getText('retrieve_settings');
			menuItems += login + ",";
			menuPageItems[login] = "retrieve_settings";
		}
	}

	login = i18n.getText('delete_settings');
	menuItems += login + ",";
	menuPageItems[login] = "delete_settings";

	config = i18n.getText('config');
	menuItems += config + ",";
	menuPageItems[config] = "config";

	text = i18n.getText('information');
	menuItems += text + ",";
	menuPageItems[text] = "information";

	login = i18n.getText('login');
	menuItems += login + ",";
	menuPageItems[login] = "login";

	if (security.assertSecLevel(1)) {
		logout = i18n.getText('logout');
		menuItems += logout + ",";
		menuPageItems[logout] = "logout";
	}

	if (security.assertSecLevel(40)) {
		text = i18n.getText('upgrade_application');
		menuItems += text + ",";
		menuPageItems[text] = "application";
	}

	if (security.assertSecLevel(40)) {
		text = i18n.getText('upgrade_platform');
		menuItems += text + ",";
		menuPageItems[text] = "platform";
	}

	showPopup('p_menu',
			[{'id': 'menu_item', 'type': 'str', 'value': menuItems.replace(/,$/, "")}],
			{'cancel': [null, null]},
			"menu");
}

var helpPageItems = {}; 
function showPopupHelp() {
	var helpItems, i;

	helpItems = "";
	for (i = 0; helppages && i < helppages.length;  i++) {
		if (helppages[i].title !== null && (helppages[i].hidden !== "true" || security.canSeeHidden())) {
			helpItems += i18n.getText(helppages[i].title) + ",";
			helpPageItems[i18n.getText(helppages[i].title)] = helppages[i].name;
		}
	}

	showPopup('p_help',
			[{'id': 'help_item', 'type': 'str', 'value': helpItems.replace(/,$/, "")}],
			{'cancel': [null, null]},
			"menu");
}

function helpItemSelected(tr) {
	var page = helpPageItems[tr.firstChild.firstChild.getAttribute("lastval")];

	closePopup("menu");

	showPopup("help/" + configuration.etu_language + "/" + page, [],
			{'cancel': [null, null]},
			"help");
}


function menuItemSelected(tr) {
	var page = menuPageItems[tr.firstChild.firstChild.getAttribute("lastval")];

	closePopup("menu");
	switch (page) {
	case 'discovery':
		pages = [];
		ip = null;
		initMainCont('engine/', false); // TODO Not good

		updateHeader("", "", null);
		break;
	case 'login':
		showLoginPopup(null, null, null, 'sec_level');
		break;
	case 'logout':
		security.logout();
		break;
	case 'config':
		showPopup('p_config',
				[],
				{'cancel': [null, null], 'conf_set_nw': [setNwConfig, null] });
		break;
	case 'information':
		showPopup('p_information', null, {'cancel': [null, null]});
		break;
	case 'application':
		showPopup('p_application', null, {'cancel': [null, null]});
		navctx.active.keyHitHook = function () {
			document.getElementById('ajax_file_msg').innerHTML = "";
		};
		break;
	case 'platform':
		showPopup('p_platform', null, {'cancel': [null, null]});
		navctx.active.keyHitHook = function () {
			document.getElementById('ajax_file_msg').innerHTML = "";
		};
		break;
	case 'store_settings':
		storeSettings();
		break;
	case 'retrieve_settings':
		retrieveSettings();
		break;
	case 'delete_settings':
		deleteSettings();
		break;
	default:
		gotoPage(page, unitPath);
		break;
	}
}

// Update variable on page	
function doCalc(calc, val) {
	if (calc !== null) {
		val = eval(calc);
	}
	return val;
}



/*
function progBar(element, style, value)
{
  console.log("im here 2" + value);
	var progressBar;
	var val;	
	val = element.val;
	progressBar = element.progressBar;
	if (val != value)
	{
	  //if (progressBar) {progressBar.destroy();}
    //progressBar = new ProgressBar(element.id, style);
		progressBar = new ProgressBar(element.id, {'width':'100%', 'height':'10px'});
    progressBar.setPercent(value);
	}
  element.val = value;
	element.progressBar = progressBar;
	
	
	//console.log("print style: " + style);
}*/

function drawDygraph(element, style, checkUpdate, dataSource, fillgraph, average, showall) {

  var g2;
	var showit,rollavg;
	
	if (average === "true")
	  rollavg = true;
	else 
	  rollavg = false;
		
	if (showall === "true")
	  showit = true;
	else
	  showit = false;

  g2 = element.g2;
  if (!g2 || redrawGraph)
  {
    if (g2) { g2.destroy(); } //prevents memory leak

		if (showit)
		{
			    
			g2 = new Dygraph(
			element.id,
      dataSource,//"scope.csv", // path to CSV file
      { 
        labelsDivStyles: {
                'text-align': 'right',
                'background': 'none'
              },
        fillGraph: fillgraph ,
        labelsSeparateLines: true
      } 
      );
	  }
		else 
		{
      g2 = new Dygraph(
      element.id,
      dataSource,//"scope.csv", // path to CSV file
      { 
        labelsDivStyles: {
                'text-align': 'right',
                'background': 'none'
              },
				rollPeriod: 0,
        showRoller: rollavg,
        fillGraph: fillgraph ,
				visibility: [hideSeries1, hideSeries2, hideSeries3, hideSeries4, hideSeries5, hideSeries6],
        labelsSeparateLines: true
      } 
      );
		}
  }
    element.g2 = g2;
		//style = "width:0px; height:0px;";
    g2.style = style;///////////////////////
		redrawGraph = false;
		//console.log("print style: " + style);
}

function drawGraph(element, data, optds, scalex, pointsx) {
	var jg, gl, oldW, xoffset, xpaddingright, ypaddingbottom, ypaddingtop, width, height, maxV, maxD, values, value, lines, i, xpos, c, xvalues, pointsxs, xlabels, maxValue, colors, W, yvalues;

	jg = element.jg;
	gl = element.graphlines;
	oldW = element.oldW;
	xoffset = 30;
	xpaddingright = 15;
	ypaddingbottom = 25;
	ypaddingtop = 15;
	width = element.offsetWidth - xoffset - xpaddingright;
	height = element.offsetHeight - ypaddingbottom - ypaddingtop;
	maxV = 0;
	maxD = 0;
	lines = data.split(";");

	for (i = 1; i < lines.length; i++) {
		values = lines[i].split(",");
		for (c = 0; c < values.length; c++) {
			maxV = Math.max(values[c], maxV);
		}
	}
	maxV = Math.floor((maxV + 100) / 100) * 100;

	xvalues = [];
	xlabels = [];
	values = lines[0].split(",");
	pointsxs = pointsx.split(",");

	for (i = 0; i < pointsxs.length; i++) {
		xlabels[i] = parseInt(pointsxs[i], 10);
		maxD = Math.max(maxD, xlabels[i]);
	}

	maxValue = doCalc(scalex, maxD); // TODO  parseFloat(values[0]);
	for (i = 0; i < values.length; i++) {
		value = doCalc(scalex, parseFloat(values[i]));
		xpos = parseInt((width * value) / maxValue, 10);

		if (values[i] < maxD) {
			xvalues.push(xoffset + xpos);
		}
	}


	colors = ["#FF0000", "#0000FF", "#009900"]; // TODO Use CSS
	if (!jg) {
		jg = new jsGraphics(element);
		element.jg = jg;
	}

	W = "" + getPageSize()[0];

	//if (oldW !== W) { //removed to make y scale update MW
	//	element.oldW = W; //removed to make y scale update MW
		jg.clear();

		jg.drawRect(xoffset + 0, ypaddingtop, width, height);

		jg.setFont("DejaVu Sans Mono", "12px", Font.PLAIN); // TODO Use CSS
		for (i = 0; i < 5; i++) {
			jg.drawString(i * maxV / 4 / 10, xoffset - 25, ypaddingtop + height -  i * (height / 4) - 8);
			jg.drawLine(xoffset - 5, ypaddingtop + height - i * height / 4, xoffset, ypaddingtop + height - i * height / 4);
		}

		//var labels = [10, 100, 400, 800];
		for (i = 0; i < xlabels.length; i++) {
			value = doCalc(scalex, xlabels[i]);
			xpos = parseInt((width * value) / maxValue, 10);

			if (xlabels[i] < maxD) {
				jg.drawString(xlabels[i], xoffset + xpos - 15, ypaddingtop + height + 5);
				jg.drawLine(xoffset + xpos, ypaddingtop + height, xoffset + xpos, ypaddingtop + height + 5);
			}
		}

		for (i = 1; i < optds.length; i++) {
			jg.setColor(colors[i - 1]);
			jg.fillEllipse(xoffset + (i - 1) * width / (optds.length - 1), 5, 4, 4);
			jg.setColor("#000000"); // TODO Use CSS
			jg.drawString(i18n.getText(optds[i]), 6 + xoffset + (i - 1) * width / (optds.length - 1), 0);
		}

		jg.paint();
	//} //removed to make y scale update MW

	if (!gl) {
		gl = new jsGraphics(element);
		element.graphlines = gl;
	} else {
		gl.clear();
	}

	for (i = 1; i < lines.length; i++) {
		values = lines[i].split(",");
		yvalues = [];
		gl.setColor(colors[i - 1]);
		for (c = 0; c < values.length; c++) {
			yvalues.push(parseInt(ypaddingtop + height - ((height * parseFloat(values[c])) / maxV), 10));
			gl.drawEllipse(xvalues[c] - 2, yvalues[c] - 2, 4, 4);
		}
		gl.drawPolyline(xvalues, yvalues);
	}
	gl.paint();
}

function updField(showOnly, name, type, value, readwrite, optS, optV, optD, optC, size, sec, tagVal) {
	var i, disabled, valueString, element, lastval, ht, text, outline, typeId, color;

	element = document.getElementById(name);
	if (!element) {
		return null;
	}
	// Store away the current value in both the doc and the span as lastval="value"
	if (!showOnly) {
		lastval = element.getAttribute("lastval");
		if (lastval === "" + value) {
			if (element.getAttribute("dirty") !== "true") {
				return;
			} else {
				element.setAttribute("dirty", "false");
			}
		} 

		element.setAttribute("lastval", value);
	}
	ht = null;
	switch (type) {
	case 'btn':
		// Disabled status may have changed
		navctx.active.fieldJumpCache = [];
		text = "";
		disabled = false;
		for (i = 0; i < optS.length; i++) {
			if (optV[i] == value) {
				text = i18n.getText(optS[i]);
				if (optD !== null) {
					disabled = (optD[i] === "true");
				}
				break;
			}
		}
		ht = "<input type='button' class='val_btn" + (readwrite && !showOnly ? " val_rw" : "") + (security.assertSecLevel(sec) ? "" : " val_wrongsec") + (disabled ? " disabled" : "") + "'" + (disabled ? " disabled='disabled' " : "") + "value='" + text + "'  size='" + size + "'/>";
		valueString = text;
		typeId = 1;
	    break;
	case 'tog':
		valueString = "X";
		if (typeof value === 'number') {
			color = "";
			if (optC) {
				if (optC[value] && optC[value].length > 0) {
					color = "background-color:" + optC[value];
				}
			}

			ht = "<input " + ((readwrite && !showOnly)?"":"disabled='disabled'") + " type='button' style='" + color + "' class='val_tog" + (readwrite && !showOnly ? " val_rw" : "") + (value ? ' tog_checked' : '') + (security.assertSecLevel(sec) ? "" : " val_wrongsec") + "'  " + "' value='' />"; // &#10004 is checkmark
		typeId = 2;
		} else {
			ht = "";
		}
		break;
	case 'drp':
	case 'txt':
		valueString = "";
		disabled = false;
		for (i = 0; i < optV.length; i++) {
			if (optV[i] == value) {
				valueString = i18n.getText(optS[i]);
				if (optD !== null) {
					disabled = (optD[i] === "true");
				}
				break;
			}
		}
		ht = "<label class='val_val" + (readwrite && !showOnly ? " val_rw" : "") + (security.assertSecLevel(sec) ? "" : " val_wrongsec") + (disabled ? " disabled" : "") + "'" + (disabled ? " disabled='disabled' " : "") + " >" + valueString + "</label>";
		typeId = 0;
		break;
	case 'pwd':
		valueString = "****";
		ht = "<label class='val_val" + (readwrite && !showOnly ? " val_rw" : "") + (security.assertSecLevel(sec) ? "" : " val_wrongsec") + "' >" + valueString + "</label>";
		typeId = 0;
		break;
	default:
		valueString = value;
		ht = "<label class='val_val" + (readwrite && !showOnly ? " val_rw":"") + (security.assertSecLevel(sec) ? "" : " val_wrongsec") + "' >" + value + "</label>";
		typeId = 0;
		break;
	}
	element.setAttribute("lastvalstring", valueString);
	outline = null;
	if (ht !== null) {
		if (type === "btn" || type === "tog") {
			outline = element.style.outline;
			if (!outline && element.firstChild) {
				outline = element.firstChild.style.outline;
			}
			G.nav.unmarkElement(element);
		}
		element.innerHTML = ht;
	}
	//element.firstChild.setAttribute("onclick", "onClickVal(this, " +  typeId + ", true);" );
	if (element.firstChild) {
		element.firstChild.onclick = function () { onClickVal(element.firstChild, typeId, true);};
		element.valref = tagVal;
	}
	if (outline && (type === "btn" || type === "tog")) {
		G.nav.markSelectedField();
	}
	return 0;
}

function calcDecimals(calc) {
	var val, precData;

	val = 1;
	precData = eval(calc);
	if (typeof precData === 'number' && precData !== val && precData > 0 && precData < 1) {
    if (-1 * Math.floor(Math.log(precData) / Math.LN10) > 3) //never more than 3 decimals MW
      return 2;
    else 
		  return  -1 * Math.floor(Math.log(precData) / Math.LN10);
	}
	return 0;
}

function updateVariable(tagVal, type, value, bitPos, showOnly, time, pos, isUnavail) {
	var atId, element, lastval, readwrite, atFType, atCalc, sec, data, decimals, val, atOptS, atOptV, atOptD, atOptC, rawOptdD, atSize,  atScalex, atPointsx, atStyle, atCheckUpdate, atFile, atFillGraph, atAverage, atHideSeries, atInternal, atShowAll;

	atId = "ajax_" + tagVal.getAttribute('id') + ((typeof pos === 'number') ? pos : "");
	element = document.getElementById(atId);
	if (!element || (element.getAttribute("lastupdatetime") !== null) &&  (time < element.getAttribute("lastupdatetime"))) {
		return;
	}

	if (isUnavail) {
		lastval = element.getAttribute("lastval");
		if (lastval !== '\u0007') {
			element.innerHTML = '<label class="val_val disabled">?</label>'; 
			navctx.active.fieldJumpCache = [];
			element.setAttribute("lastval", '\u0007');
		}
		return;
	} else if (element.getAttribute("lastval") === '\u0007') {
		navctx.active.fieldJumpCache =  [];
	}

	readwrite = tagVal.getAttribute('varw') !== null || tagVal.getAttribute('vare') !== null;
	atFType = tagVal.getAttribute('type');
	atCalc = tagVal.getAttribute('calc');
	sec = tagVal.getAttribute('sec');
  // Do some parsing
	switch (type) {
	case 'int':
		data = parseInt(value, 10);
		if (bitPos !== -1) {
			data = (data>>bitPos) & 1;
		}
		break;
	case 'flt':
		data = parseFloat(value);
		break;
	case 'str':
		data = value; // value.replace(/\s*$/g,'');
		break;
	default:
		data = value;
		break;
	}

	if (value === null) {
		data = "";
	}

  // Re-calc upon request
	if (atCalc !== null && atCalc !== '' && value !== null) {
		// TODO consider different strategy
		decimals = calcDecimals(atCalc);

		val = data;
		data = eval(atCalc);
		try {
			if ((typeof data === 'number') && (decimals > 0)) {
				data = data.toFixed(decimals); 
			}
		} catch (ex) {
			console.log("Decimal setting error err: " + ex);
		}
	}

	switch (type) {
	case 'dte':
		if (data !== '') {
			data = i18n.formatDate(data);
		}
		break;
	case 'tme':
		// TODO format localized
		break;
	}

  // Final treatment and update on page
	switch (atFType) {
	case 'btn':
		atOptS = tagVal.getAttribute('optds').split(',');
		atOptV = tagVal.getAttribute('optdv').split(',');
		atOptD = null;
		rawOptdD = tagVal.getAttribute('optdd');
		if ((rawOptdD !== null) && (rawOptdD !== "")) {
			atOptD = rawOptdD.split(',');
		}
		atSize = tagVal.getAttribute('size');
		updField(showOnly, atId, atFType, data, readwrite, atOptS, atOptV, atOptD, null, atSize, sec, tagVal);
		break;
	case 'txt':
	case 'drp':
		atOptS = tagVal.getAttribute('optds').split(',');
		atOptV = tagVal.getAttribute('optdv').split(',');
		atOptD = null;
		rawOptdD = tagVal.getAttribute('optdd');
		if ((rawOptdD !== null) && (rawOptdD !== "")) {
			atOptD = rawOptdD.split(',');
		}
		updField(showOnly, atId, atFType, data, readwrite, atOptS, atOptV, atOptD, null,  null, sec, tagVal);
		
		
		
		atInternal = tagVal.getAttribute('internal');
	  if (atInternal == "true")
		{
		  atHideSeries = tagVal.getAttribute('series');
		  switch (atHideSeries) {
		  case '0':
			  if (data == '1')
				{
				  if (hideSeries1 == 0){
						redrawGraph = true;
					}
			    hideSeries1 = 1;
			  }
				else {
				  if (hideSeries1 == 1){
						redrawGraph = true;
					}
			    hideSeries1 = 0;
				}
			break;
			case '1':
			  if (data == '1')
				{
				  if (hideSeries2 == 0){
						redrawGraph = true;
					}
			    hideSeries2 = 1;
			  }
				else {
				  if (hideSeries2 == 1){
						redrawGraph = true;
					}
			    hideSeries2 = 0;
				}
			break;
			case '2':
			  if (data == '1')
				{
				  if (hideSeries3 == 0){
						redrawGraph = true;
					}
			    hideSeries3 = 1;
			  }
				else {
				  if (hideSeries3 == 1){
						redrawGraph = true;
					}
			    hideSeries3 = 0;
				}
			break;
			case '3':
			  if (data == '1')
				{
				  if (hideSeries4 == 0){
						redrawGraph = true;
					}
			    hideSeries4 = 1;
			  }
				else {
				  if (hideSeries4 == 1){
						redrawGraph = true;
					}
			    hideSeries4 = 0;
				}
			break;
			case '4':
			  if (data == '1')
				{
				  if (hideSeries5 == 0){
						redrawGraph = true;
					}
			    hideSeries5 = 1;
			  }
				else {
				  if (hideSeries5 == 1){
						redrawGraph = true;
					}
			    hideSeries5 = 0;
				}
			break;
			case '5':
			  if (data == '1')
				{
				  if (hideSeries6 == 0){
						redrawGraph = true;
					}
			    hideSeries6 = 1;
			  }
				else {
				  if (hideSeries6 == 1){
						redrawGraph = true;
					}
			    hideSeries6 = 0;
				}
			break;
	    default:
			break;
		  }
		}
	  break;
	case 'grp':
		atOptS = tagVal.getAttribute('optds').split(',');
		atScalex = tagVal.getAttribute('scalex');
		atPointsx = tagVal.getAttribute('pointsx');
		drawGraph(element, data, atOptS, atScalex, atPointsx);
		break;
  case 'dsc':
    atStyle = tagVal.getAttribute('style');
    atFile = tagVal.getAttribute('datasource');
    atCheckUpdate = tagVal.getAttribute('checkupdate');
    atFillGraph = tagVal.getAttribute('fillgraph');
		atAverage = tagVal.getAttribute('averaging');
		atShowAll = tagVal.getAttribute('showall');
		drawDygraph(element, atStyle, atCheckUpdate, atFile, atFillGraph, atAverage, atShowAll);
		break;
	case 'prg':
    atStyle = tagVal.getAttribute('style');
		progBar(element, atStyle, data);
		break;
	default:
		if (tagVal.getAttribute('optdc')) {
			atOptC = tagVal.getAttribute('optdc').split(',');
		}
		updField(showOnly, atId, atFType, data, readwrite, null, null, null, atOptC, null, sec, tagVal);
		break;
	}
}

var VALID_PLATFORM_FILE_NAME = /^platform-.*\.jffs2$/;

function upgradePlatform() {
	var filename, result; 

	filename = document.getElementById("ajax_file_menu_items").getAttribute("lastval");

	if (!VALID_PLATFORM_FILE_NAME.test(filename)) {
		document.getElementById('ajax_file_msg').innerHTML = i18n.getText("platform_invalid_file");

		popupview.handleData([{'id': 'ok', 'type': 'int', 'value': 0}], new Date().getTime());
		return;
	}

	document.getElementById('ajax_file_msg').innerHTML = i18n.getText("platform_upgrade_started");
	G.nav.disableNavigation();
	try {
		result = sendLocalValueSync("engine/w_upgrade_platform.cgi", filename);
	} catch (e) {
		result = 503;
	}
	G.nav.enableNavigation();
	if (result === 503) {
		document.getElementById('ajax_file_msg').innerHTML = i18n.getText("platform_invalid_file");
		popupview.handleData([{'id': 'ok', 'type': 'int', 'value': 0}
					], new Date().getTime());
	}
}

var VALID_ENGINE_FILE_NAME = /^WebPkgEngine-.*\.tar\.bz2$/;

function upgradeApplication() {
	var filename = document.getElementById("ajax_file_menu_items").getAttribute("lastval"), result;

	if (!VALID_ENGINE_FILE_NAME.test(filename)) { // TODO Escape with double \  ??
		document.getElementById('ajax_file_msg').innerHTML = i18n.getText("application_invalid_file");

		popupview.handleData([{'id': 'ok', 'type': 'int', 'value': 0}], new Date().getTime());
		return;
	}

	document.getElementById('ajax_file_msg').innerHTML = i18n.getText("application_upgrade_started");
	result = sendLocalValueSync("engine/w_upgrade_application.cgi", filename);
	if (result === 503) {
		document.getElementById('ajax_file_msg').innerHTML = i18n.getText("application_invalid_file");
		popupview.handleData([{'id': 'ok', 'type': 'int', 'value': 0}
					], new Date().getTime());
	} else {
		document.cookie = "upgraded=yes; expires=31-Dec-2037 23:59:59 GMT";
		window.location.reload();
	}
}

function hasClass(element, className) {
	var classAttribute;
	classAttribute = element.getAttribute("class");
	if (classAttribute === null) { // IE6 workaround
		classAttribute = element.getAttribute("className");
	}
	return classAttribute && (classAttribute.match(className) !== null);
}

function dirtyAllFields(target_name) {
	var classAttribute, labels, i, target;

	target = document.getElementById(target_name);
	labels = target.getElementsByTagName("span");
	for (i = 0; i < labels.length; i++) {
		if (hasClass(labels[i], /ajax/)) {
			labels[i].setAttribute("dirty", "true");
		}
	}
}

// TODO Varf?r beh?vs padIp?
function padIp(value) {
	var parts, newvalue, i;

	parts = value.split(".");
	newvalue = "";
	for (i = 0; i < parts.length; i++) {
		if (newvalue !== "") {
			newvalue += ".";
		}
		newvalue += new Array(3 - parts[i].length + 1).join('0') + parts[i];
	}
	return newvalue;
}

function padStr(str, padchar, size) {
	if (typeof str === 'number') {
		console.log("padStr: String must be string, not 'number'"); 
	}
	var padding, i;
	padding = '';
	for (i = 0;i < (size - str.length); i++) {
		padding += padchar;
	}
	return padding + str;
}

function onFocusVal(element) {
}

function onBlurVal(element, type) {
	var parent = element.parentNode;
	if (parent === null || parent === undefined) {
		return;
	}

	element.removeAttribute("onchange");
	element.removeAttribute("onblur");

	if (type === 2) { // tog
		parent.innerHTML = "<input disabled='disabled' type='button' class='val_tog val_clckd_tog value='' />";
	} else {
		parent.innerHTML = "<label class = 'val_val val_rw' onclick = 'onClickVal(this," + type + ",true)'>" + parent.getAttribute('lastvalstring') + "</label>";
		parent.removeAttribute("lastupdatetime");
	}
	noSelect = false;
	G.nav.markSelectedField();
}

var folderClick;
function populateCptPageMenu(pages) {
	var target, lasttitle, result, inSubMenu, i, oldfolds, oldpages, lis, node, pageclass;

	target = document.getElementById("cpt_menu_items");
	if (target === null) {
		return;
	}

	oldfolds = [];
	oldpages = [];
	i = 0;
	lis = target.getElementsByTagName("li");
	if (lis && lis.length > 0) {
		for (li in lis) {
			node = lis[li];
			if (typeof node === 'object') {
				oldfolds[node.getAttribute("id")] = node.getAttribute("class");
				if (oldfolds[node.getAttribute("id")] === null) { // IE6 workaround
					oldfolds[node.getAttribute("id")] = node.getAttribute("className");
				}
				if (tagSpan = node.firstChild) {
					oldpages[tagSpan.getAttribute("id")] = tagSpan.getAttribute("class");
				}
			}
		}
	}

	while (target.firstChild) {
		target.removeChild(target.firstChild);
	}
	lasttitle = "";

	inSubMenu = false;
	result = "<ul class='mktree' id='cpt_menu_tree'>";

	folderClick = function (item) {
		item.parentNode.className = (item.parentNode.className === "liOpen") ? "liClosed" : "liOpen";
		return false;
	};
	for (i = 0; pages && i < pages.length;  i++) {
		if (pages[i].hidden !== "true" || security.canSeeHidden()) {
			pageclass = oldpages["pagenr" + i]?oldpages["pagenr" + i]:"bullet";
			if (!!pages[i].title && !pages[i].subtitle) {
				if (inSubMenu) {
					result += "</ul></li>";
					inSubMenu = false;
				}
				result += ('<li class="liBullet"><span id="pagenr' + i + '" class="' + pageclass + '" onclick="gotoPage(pages[' + i + '].name, unitPath);">\u00A0' + i18n.getText(pages[i].title) + '</span></li>');
			} else if (!!pages[i].title && !!pages[i].subtitle) {
				if (inSubMenu) {
					result += "</ul></li>";
				}
				result += '<li id="fold' + i + '" class="' + (oldfolds["fold"+i] ? oldfolds["fold"+i] : "liClosed") + '"><span class="' + pageclass + '" onclick="folderClick(this)">\u00A0' + i18n.getText(pages[i].title) + '</span><ul>';
				result += '<li class="liBullet"><span id="pagenr' + i + '" class="' + pageclass + '" onclick="gotoPage(pages[' + i + '].name, unitPath);">\u00A0' + i18n.getText(pages[i].subtitle) + '</span></li>';
				inSubMenu = true; 
			} else if (!!pages[i].subtitle) {
				result += '<li class="liBullet"><span id="pagenr' + i + '" class="' + pageclass + '" onclick="gotoPage(pages[' + i + '].name, unitPath);">\u00A0' + i18n.getText(pages[i].subtitle) + '</span></li>';
			} else {
				console.log("Invalid menu item, title: " + pages[i].title + ". subtitle: " + pages[i].subtitle);
			}
		}
	}
	if (inSubMenu) {
		result += "</ul></li>";
		inSubMenu = false;
	}
	result += "</ul>";
	target.innerHTML = result;
}

// Update field
// Called when clicking a value field of type 'val'
var OPTLM_VALUE_PATTERN = "=(.*?);";
function onClickVal(element, type, mouse) {
	var xatSval, xatTagName , xatEval, newelement, parent, xatOptS, xatOptV, val, c, idStr, idPos, data, lastval, tagVal, xatSec, xatFType, xatSize, xatDType, xatOptLm, xatOptLID, otherVal, ht, j, calce, decimals, calc, fixed, sel, xatCalcw, isBitvalue, ele, typ, updateCmd, xatCon;


	if (noSelect) {
		return;
	}
	if (element.getAttribute("disabled") === "disabled") {
		return;
	}

	if (mouse && navctx.active.keyHitHook) {
		navctx.active.keyHitHook();
	}

	if (!hasClass(element, /val_rw/)) {
		return;
	}

	parent = element.parentNode;
	if (parent === null) {
		return;
	}
	idStr = "";
	idPos = parent.id.indexOf("_");
	if (idPos > 0) {
		idStr = parent.id.slice(idPos + 1);
	}
	lastval = parent.getAttribute("lastval");

	tagVal = parent.valref;  //getValTagById(idStr);
	if (!tagVal) {
		console.log("Missing tagval: " + element);
		return;
	}
  //xatTagName = tagVal.getAttribute('tag');
  xatTagName = tagVal.getAttribute('varw');
	xatSval = tagVal.getAttribute('varw');
	xatEval = tagVal.getAttribute('vare');
	xatSec = tagVal.getAttribute('sec');
	if (xatSec !== null) {
		if (!security.assertSecLevel(xatSec)) {
			typ = type;
			showLoginPopup(parseInt(xatSec, 10),
				function () {
					onClickVal(element, typ, mouse);
				}, G.nav.markSelectedField);
			return;
		}
	}

	switch (type) {
	case 0: // val
		xatFType = tagVal.getAttribute('type');
		xatSize = tagVal.getAttribute('size');
		xatDType = tagVal.getAttribute('datatype');
		if (xatFType === 'drp') {
			parent.setAttribute("lastupdatetime", Number.MAX_VALUE);
			noSelect = true;
			xatOptS = tagVal.getAttribute('optds').split(',');
			xatOptV = tagVal.getAttribute('optdv').split(',');

			xatOptLm = null;
			xatOptLID = tagVal.getAttribute('optlid');
			try {
				if (xatOptLID !== null) {
					// TODO error handling
					xatOptLm = tagVal.getAttribute('optlm');
					otherVal = document.getElementById("ajax_" + xatOptLID).getAttribute('lastval');
					xatOptLm = xatOptLm.match(otherVal + OPTLM_VALUE_PATTERN)[1].split(',');
					
					//console.log("HEJ" + xatOptLm);
				}
			} catch (ex) {
				console.log("problem with 'optlm' attribute: " + ex);
			}
			

			ht = "<select class='val_drp' onchange='onChangeVal(this," + type + ")' onblur='onBlurVal(this," + type + ")'" + (xatSize ? ("size='" + xatSize + "'") : "") + ">";
			for (j = 0; j < xatOptS.length; j++) {
				if (xatOptLm !== null && xatOptLm[j] !== 'true') {
					continue;
				}
				ht += "<option ";
				if ("" + lastval === xatOptV[j]) {
					ht += "selected ";
				}
				ht += "value='" + xatOptV[j] + "'>" + i18n.getText(xatOptS[j]) + "</option>";
			}
			ht += "</select>";
			parent.innerHTML = ht;

			newelement = parent.getElementsByTagName('select');
			newelement[0].onkeypress = keyCheckDrp;
			newelement[0].focus();
			return;
		} else if (xatFType === 'edt' || xatFType === 'pwd') {
			calce = tagVal.getAttribute('calce');
			if (calce !== null) {
				val = lastval;
			}

			parent.setAttribute("lastupdatetime", Number.MAX_VALUE); 
			noSelect = true;
			parent.innerHTML = "<input class='val_val val_edt' type='text' " + (mouse ? "" : "readonly ") + "onchange='onChangeVal(this," + type + ")' onblur='onBlurVal(this," + type + ")' value='" + (mouse ? lastval : (padStr('' + lastval, (xatDType === 'str' ? ' ' : '0'), xatSize))) + "' maxlength='" + xatSize + "' size='" + xatSize + "'/>";
			newelement = parent.getElementsByTagName('input');
			newelement[0].focus();

			decimals = 0;
			if (xatDType === "int") {
				decimals = parent.getAttribute("decimals");
				if (decimals === null || decimals === 0) {
					calc = tagVal.getAttribute('calc');
					decimals = calcDecimals(calc);
					if (decimals > 0) {
						parent.setAttribute("decimals", decimals);
					}
				}
			}
			G.nav.focusField(newelement[0], xatDType);

			fixed = parent.getAttribute("containsFixed");
			if (decimals === 0 && null === fixed) {
				fixed = "false";
				for (c = 0; c < lastval.length; c++) {
					if (characters.isValid(lastval[c], xatDType) === false) {
						fixed = "true";
						break;
					}
				}
				parent.setAttribute("containsFixed", fixed);
			}
			if (fixed === "true" && !mouse) {
				if (document.selection) {
					sel = document.selection.createRange();
					sel.moveEnd("character", 1);
					sel.select();
				} else {
					newelement[0].setSelectionRange(0, 1);
				}
			}
			return;
		}
		break;
	case 1: // btn
		xatOptS = tagVal.getAttribute('optds').split(',');
		xatOptV = tagVal.getAttribute('optdv').split(',');
		//data = null;
		//for (c = 0; c < xatOptS.length; c++) {
		//	if (i18n.getText(xatOptS[c]) === element.value) {
		//		data = xatOptV[c];
		//		break;
		//	}
		//}
    data = 1;
		// Fall through
	case 2: // tog
		if (type === 2) {
			data = hasClass(element, /tog_checked/)?0:1;
		}

		if (data === null) {
			return;
		}

		xatCalcw = tagVal.getAttribute('calcw');
		if (xatCalcw !== null && xatCalcw !== '') {
			val = data;
      data = eval(xatCalcw);
		}

		isBitvalue = tagVal.getAttribute('bitvalue') !== null;
		ele = element;
		typ = type;
		updateCmd = function () {
			onBlurVal(ele, typ);
			parent.setAttribute("dirty", "true");
			if (xatEval) {
				val = data;
				eval(xatEval);
			} else {
				updateValueSync(xatSval, data, parent, isBitvalue, typ, xatDType, xatSize, xatTagName);
			}
		};
		xatCon = tagVal.getAttribute('con');
		if (xatCon && xatCon !== "false" && (!security.isAutoconfirmEnabled() || xatCon === "strict")) {
			showPopup('p_confirm',
					[{'id': 'con_autoconfirm', 'type': 'int', 'value': security.canAutoconfirm() && xatCon !== "strict" ? 1 : 0},
					{'id': 'con_confirm', 'type': 'int', 'value': 1},
					{'id': 'cancel', 'type': 'int', 'value': 1}],
				{
					'ok': [null, updateCmd],
					'cancel': [null, G.nav.markSelectedField ],
					'autoconfirm': [null, function () {
						updateCmd();
						security.enableAutoconfirm();
					}]
				});
		} else {
			updateCmd();
		}
		break;
	}
}

function onChangeVal(element, type) {
	var val, xatTagName,idStr, idPos, parent, tagVal, xatSval, xatEval, xatCon, value, xatFType, xatSize, xatCalcw, isBitvalue, xatDType, typ, updateCmd;

	parent = element.parentNode;
	if (!parent) {
		return;
	}
	idStr = "";
	idPos = parent.id.indexOf("_");
	if (idPos > 0) {
		idStr = parent.id.slice(idPos + 1);
	}

	tagVal = parent.valref; //getValTagById(idStr);
	if (!tagVal) {
		console.log("missing val: " + element);
		return;
	}
  //xatTagName = tagVal.getAttribute('tag');
  xatTagName = tagVal.getAttribute('varw');
	xatSval = tagVal.getAttribute('varw');
	xatEval = tagVal.getAttribute('vare');
	xatCon = tagVal.getAttribute('con');
	switch (type) {
	case 0: // val
	case 1: // btn
		xatFType = tagVal.getAttribute('type');
		xatSize = tagVal.getAttribute('size');
		xatCalcw = tagVal.getAttribute('calcw');
		isBitvalue = tagVal.getAttribute('bitvalue') !== null;
		xatDType = tagVal.getAttribute('datatype');

		switch (xatFType) {
		case 'drp':
			value = element[element.selectedIndex].value;
			break;
		case 'pwd':
		case 'edt':
			value = element.value;
			break;
		}

    if (value !== 'max' && value !== 'Max' && value !== 'Min' && value !== 'min' && value !== 'rev' && value !== 'Rev' && value !== 'Fac' && value !== 'fac')
    {
		  if (xatCalcw !== null && xatCalcw !== '') {
			  val = value;
			  value = eval(xatCalcw);
		  }
    }
		noSelect = false;
		element.onchange = null;
		element.onblur = null;
		element.blur();

		typ = type;
		updateCmd = function () { 
			updateVariable(tagVal, typ, value, 0, true, Number.MAX_VALUE);

			G.nav.markSelectedField();
			parent.setAttribute("dirty", "true");
			if (xatEval) {
				  val = value;
				  parent.innerHTML = "<label class='val_val val_rw' onclick='onClickVal(this,0,true)'>" + parent.getAttribute('lastvalstring') + "</label>";
				  parent.setAttribute("lastupdatetime", new Date().getTime());
				  parent.setAttribute("lastval", val);
				  eval(xatEval);
			} else {
				updateValueSync(xatSval, value, parent, isBitvalue, typ, xatDType, xatSize, xatTagName);
			}
		};

		if (xatCon && xatCon !== "false" && (!security.isAutoconfirmEnabled() || xatCon === "strict")) {
			if (xatFType === 'drp' && ie) { // Bad workound for IE6 which doesn't support z-index for "select"
				element.style.visibility = "hidden";
			}
			showPopup('p_confirm',
					[{'id': 'con_autoconfirm', 'type': 'int', 'value':  security.canAutoconfirm() && xatCon !== "strict" ? 1 : 0},
					{'id': 'con_confirm', 'type': 'int', 'value': 1},
					{'id': 'cancel', 'type': 'int', 'value': 1}],
					{
					'ok': [null, updateCmd],
					'cancel': [null, function () {
						onBlurVal(element, typ);
						parent.setAttribute("dirty", "true");
					}],
					'autoconfirm': [null, function () {
						updateCmd();
						security.enableAutoconfirm();
					}]
				});
		} else {
			updateCmd();
		}
		break;
	}
}


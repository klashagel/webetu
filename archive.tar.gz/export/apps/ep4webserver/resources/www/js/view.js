var etu_view = function () {
	var t= {
		showNotLoggedIn: function () {
			document.getElementById('secstatus').innerHTML = i18n.getText("not_logged_in");
		},
		showError: function(text) {
			document.getElementById('engine_nwstatus').innerHTML=i18n.getText(text);
		},
		clearError: function() {
			document.getElementById('engine_nwstatus').innerHTML="";
		},
		updateLogoutTimer: function(timeLeft) {
			var timeString = Math.floor(timeLeft / 60000) + ":" + (timeLeft / 1000 % 60 < 10 ? "0" : "") + Math.floor(timeLeft / 1000 % 60); 
			document.getElementById('secstatus').innerHTML = i18n.getText("curr_sec_level") + ": " + i18n.getText(security.getLevelInfo().name) +
				". " + i18n.getText("logout_in") + ": " + timeString +
				"." + (security.isAutoconfirmEnabled() ? i18n.getText("autoconfirm_on") : "");
		},
		showNodeName: function(nodeName) {
			// TODO Use on ETU for header to always have updated value?!
		}
	};
	security.logout.subscribe(t.showNotLoggedIn);
	checkLogoutTimer.subscribe(t.updateLogoutTimer);
	return t;
};

var cpt_view = function () {
	var t = {
		showNotLoggedIn: function () {
			cptview.handleData(
			[
				{'id': 'cpt_autoconfirm', 'type': 'int', 'value': 0},
				{'id': 'cpt_logout_tme', 'type': 'str', 'value': "00:00"},
				{'id': 'cpt_sec_level', 'type': 'int', 'value': security.getSecLevel()}
			], new Date().getTime());
		},
		showError: function(text) {
		},
		clearError: function() {
		},
		updateLogoutTimer: function(timeLeft) {
			var timeString = Math.floor(timeLeft / 60000) + ":" + (timeLeft / 1000 % 60 < 10 ? "0" : "") + Math.floor(timeLeft / 1000 % 60); 
			cptview.handleData(
			[
				{'id': 'cpt_autoconfirm', 'type': 'int', 'value': security.isAutoconfirmEnabled()?1:0},
				{'id': 'cpt_logout_tme', 'type': 'str', 'value': timeString},
			{'id': 'cpt_sec_level', 'type': 'int', 'value': security.getSecLevel()}
			], new Date().getTime());
		},
		showNodeName: function(nodeName) {
			document.title = nodeName + " - Web Interface";
		}
	};
	security.logout.subscribe(t.showNotLoggedIn);
	checkLogoutTimer.subscribe(t.updateLogoutTimer);
	return t;
};

var i18n = (function () {
	//var	translationMap = [];

	function translateData(page, tag, attribute) {
		var vals, i, key;

		vals = page.getElementsByTagName(tag);
		for (i = 0; i < vals.length; i++) {
			key = vals[i].getAttribute(attribute);
			if (key) {
				vals[i].setAttribute(attribute, i18n.getText(key));
			}
		}
	}

	return {
		getText: function (key) {
			var res;

			// TODO Trim key here or when read to make sure extra whitspaces don't cause a problem
			res = languagesTranslationMap[key];
			if (!res) {
				res = translationMap[key];
			}
			if (!res) {
				res = engineTranslationMap[key];
			}
			if (!res) {
				// console.log("Warning: Translation for string '" + key + "' not found.");
				return key;
			}
			return res;//.replace(/ /g,"\u00A0");
		},
		translatePage: function (page) {
			translateData(page, 'val', 'label');
			translateData(page, 'val', 'title');
			translateData(page, 'val', 'unit');
			translateData(page, 'frm', 'title');
			translateData(page, 'col', 'title');
			translateData(page, 'hdr', 'title');
		},
		formatDate: function(value) {
			// TODO format localized
			var parts = value.split('-');
      if (parts[0] == 0) return "";
      if (parts[0]<100) return "";
      if (parts[0]>200) return "";
			return "" + (parseInt(parts[0], 10) + 1900) + "-" + parts[1] + "-" + parts[2];
		}
	}
}());

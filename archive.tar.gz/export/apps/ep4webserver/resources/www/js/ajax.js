/* Alstom web package (c) 2008-2010
 * Author: Anders Risberg, anders@arisberg.com
 *         John Kjellberg, john.kjellberg@power.alstom.com
 */
//var xmlPage = null;
var mainview = null;
var pages = [];
var helppages = [];
var reloadTime = null;
var xmlConf = null;
var homePage = -1;
var unitPath = null;
var configFile = null;
var menuUnsubscriber = null;
var keyHitHook = null;
var engineTranslationMap = [];
var languagesTranslationMap = [];
var configuration = [];
var executeCounter = 0;
var conf = [];
conf[true] = {};
conf[false] = {};
var isOnController = false;
var doCanvas = true;
/*global etu_view etu_nav keyCheck cpt_view cpt_nav updateValueSync currLst etu_display_ping init_sec i18n  ip showPopup ActiveXObject DOMParser XSLTProcessor security currPageIndex  navctx translationMap currNodeName sec_ping */


/*
if (typeof Object.create !== 'function') {
	Object.create = function (o) {
		var F = function () {};
		F.prototype = o;
		return new F();
	};
}
*/


var pageview = function (aTargetName, aUnitPath) {
	var target, targetName, lUnitPath, fname, xmlPage, state = 0, that;
	var pageDataUnsubscriber = [];

	targetName = aTargetName;
	lUnitPath = aUnitPath;

	target = document.getElementById(targetName);

	function pageReLoad() {
		var xmlXslt, xmlRes, xmlHttp, datapAttribute, xsltFile, myCounter;

		executeCounter++;
		myCounter = executeCounter;
		xmlRes = null;
		xmlHttp = new XMLHttpRequest();
		datapAttribute = null;
		xsltFile = null;

		xmlHttp.open("GET", lUnitPath + fname + ".xml", false);
		xmlHttp.onreadystatechange = function () {
			if (this.readyState === XMLHttpRequest.DONE) {
				xmlRes = this.responseXML;
				if (xmlRes === null) {
					checkXML(this.responseText);
					return null;
				}
				if (xmlRes.getElementsByTagName('prop').length !== 0) {
					xsltFile = lUnitPath + 'xfrm/' + xmlRes.getElementsByTagName('prop')[0].getAttribute('xslt');
				}
			}
		};
		xmlHttp.send(null);
		// Don't continue to load page if user have already switched
		if ((myCounter !== null) && (myCounter !== executeCounter)) {
			return null;
		}

		if (xmlRes === null) {
			console.log("Could not load page: " + lUnitPath + fname + ".xml");
			return null;
		}

		i18n.translatePage(xmlRes);

		if (xmlRes !== null && xsltFile !== null) {
			xmlXslt = xsltLoader(xsltFile);

			// Don't continue to load page if user have already switched
			if ((myCounter !== null) && (myCounter !== executeCounter)) {
				return null;
			}

			applyXslt(xmlRes, xmlXslt, target);
		}

		if (xmlRes !== null) 
		{
			xmlPage = xmlRes;
			navctx.active.xmlPage = xmlPage;
		}
		datapAttribute = xmlRes.getElementsByTagName('prop')[0].getAttribute('datap');
		if (datapAttribute) {
			currpageview = that;
			eval(datapAttribute);
		}

		return xmlRes;
	}

	function xsltLoader(fname) {
		var xmlRes, xmlHttp;

		xmlRes = null;
		xmlHttp = new XMLHttpRequest();
		xmlHttp.open("GET", fname, false);
		xmlHttp.onreadystatechange = function () {
			if (this.readyState === XMLHttpRequest.DONE) {
				xmlRes = this.responseXML;
				if (xmlRes === null) {
					checkXML(this.responseText);
					return null;
				}
			}
		};
		xmlHttp.send(null);
		return xmlRes;
	}

	function pageLoader(fn) {
		var xmlRes;

		fname = fn;

		xmlRes = pageReLoad();
		return xmlRes;
	}

	function createScrollBar(objId, rows, position, items) {
		var bar, table, headings, offset, height;

		bar = document.getElementById("ajax_" + objId + "_bar");
		if (!bar) {
			return;
		}

		table = bar.previousSibling;
		if (!table.tagName) {
			table = table.previousSibling;
		}

		headings = table.getElementsByTagName('th');
		offset = 0;
		if (headings.length > 0) {
			offset = headings[0].offsetHeight;
		}

		height = table.offsetHeight - offset;
		bar.style.height = height + "px";
		bar.style.top = offset + 'px';
		bar.innerHTML = '<DIV style="height:' + (Math.min(height, 1 + (height * rows) / items) - 4) + 'px;background-color:#888;margin:2px;top:' + Math.floor((height * position) / items)  + 'px;position:relative;"></DIV>';
	}


	function updateList(tagVal, type, value, bitPos, showOnly, time, isUnavail) {
		var values, lstId, rows, scrollStart, nr_of_items, i;

		values = value.split(',');

		lstId = tagVal.parentNode.getAttribute('id');
		rows = tagVal.parentNode.getAttribute('rows');
		scrollStart = parseInt(tagVal.parentNode.getAttribute('scroll_start'), 10);
		if (isNaN(scrollStart)) {
			scrollStart = 0;
		}

		nr_of_items = value.length > 0 ? values.length : 0;
		if (parseInt(tagVal.parentNode.getAttribute('nr_of_items'), 10) !== nr_of_items) {
			tagVal.parentNode.setAttribute('nr_of_items', nr_of_items);
			navctx.active.fieldJumpCache = [];
		}

		createScrollBar(lstId, rows, scrollStart, values.length);

		for (i = 0; i < rows; i++) {
			updateVariable(tagVal, type, scrollStart + i < values.length ? values[scrollStart + i] :null, bitPos, showOnly, time, i, isUnavail);
		}
	}

	function handleDatum(atId, atType, atFlags, isUnavail, value, time, dataReloader) {
		// Get the flags if bit-values
		var xatFlags, tagVal, varName, j, k, dataReloader;

		// TODO Very special case.
		if (atId == "engine_nodename") {
			// TODO Use on ETU for header to always have updated value?!
			G.view.showNodeName(value.replace(/^\s+/, '').replace(/\s+$/, '')); 
			return; 
		}

		xatFlags = null;
		if (atFlags && atType === 'int') {
			xatFlags = atFlags.split(',');
			if (xatFlags.length > 32) { 
				xatFlags = null;
			}
		}


		// Get all 'val's with this id
		for (j = 0; j < xmlPage.getElementsByTagName('val').length; j++) {
			tagVal = xmlPage.getElementsByTagName('val')[j];
			varName = tagVal.getAttribute('var');
			if (atId === varName) {
				if (tagVal.parentNode.nodeName === 'lst') {
					tagVal.parentNode.reloadLst = dataReloader;
					updateList(tagVal, atType, value, -1, false, time, isUnavail);
				} else {
					updateVariable(tagVal, atType, value, -1, false, time, null, isUnavail);
				}
				tagVal.setAttribute('datatype', atType);
			}
			else if (xatFlags !== null) {
				for (k = 0; k < xatFlags.length; k++) {
					if (xatFlags[k] !== '' && xatFlags[k] === varName) {
						tagVal.setAttribute("bitvalue", "true");
						if (tagVal.parentNode.nodeName === 'lst') {
							tagVal.parentNode.reloadLst = dataReloader;
							updateList(tagVal, atType, value, k, false, time, isUnavail);
						} else {
							updateVariable(tagVal, atType, value, k, false, time, null, isUnavail);
						}
						break;
					}
				}
			}
		}
	}

	function blankAllFields(target_name) {
		var target, i, labels;

		target = document.getElementById(target_name);

		// TODO Probably disable all fields to disallow navigation
		labels = target.getElementsByTagName("span");
		for (i = 0; i < labels.length; i++) {
			if (hasClass(labels[i],/ajax/)) {
				noSelect = false;
				labels[i].removeAttribute("lastupdatetime");
				labels[i].innerHTML = '<label class="val_val disabled">?</label>';
				labels[i].setAttribute("lastval", '\u0007');
				navctx.active.fieldJumpCache = [];
			}
		}
	}

	return that = {
		getValTagById: function (idStr) {
			var i, tags;

			tags = xmlPage.getElementsByTagName('val');
			for (i = 0; i < tags.length; i++) {
				if (idStr === tags[i].getAttribute('id')) {
					return tags[i];
				}
			}
		},
		reload: function() {
			pageReLoad();
		},
		load: function (fname) {
			try {
				return pageLoader(fname);
			} catch (e) {
				console.log("load: got exception: " + e);
				return null;
			}
		},
		start: function () {
			var dataFiles, dataAttribute, polling, i;

			if (state == 1) return;
			state = 1;

			dataFiles = null;
			dataAttribute = xmlPage.getElementsByTagName('prop')[0].getAttribute('data');
			dataFiles = dataAttribute === null ? null : dataAttribute.split(",");
			polling = xmlPage.getElementsByTagName('prop')[0].getAttribute('polling');

			for (i in dataFiles) {
				if (polling && polling === "no") {
					dataLoader(lUnitPath + dataFiles[i], this.handlePollData);
				} else {
					pageDataUnsubscriber.push(subscribePoller(lUnitPath + dataFiles[i], this.handlePollData));
				}
			}
		},
		stop: function () {
			state = 2;
			while (!!(unsub = pageDataUnsubscriber.pop())) {
				unsub();
			}
		},
		handlePollData: function (aXmlRes, aTime) {
			var i, data, value, unavail, isUnavail, xmlRes, time, dataReloader;

			xmlRes = aXmlRes;
			time = aTime;
			if (xmlRes === null) {
				G.view.showError("node_connection_problem");
				blankAllFields('cont');

				return;
			}

			G.view.clearError();

			dataReloader = function () {
				this.handlePollData(xmlRes, time);
			};

			for (i = 0; i < xmlRes.getElementsByTagName('data').length; i++) {
				data = xmlRes.getElementsByTagName('data')[i];
				value = "";
				if (data.childNodes.length > 0) {
					value = data.childNodes[0].nodeValue;
				} 
				unavail = data.getAttribute("unavailable");
				isUnavail = false;
				if (unavail && unavail === "true") {
					isUnavail = true;
				}
				handleDatum(data.getAttribute('id'), data.getAttribute('type'), data.getAttribute('flags'), isUnavail, value, time, dataReloader);
			}
			if (navctx.active.currFieldIndex === -1) {
				G.nav.navPageInit(xmlPage);
			}
		},
		handleData: function (aData, aTime, updateOnly) {
			var i, time, data, dataReloader, that;
			data = aData;
			time = aTime;
			that = this;

			dataReloader = function () {
				that.handleData(data, time);
			};

			for (i = 0; i < data.length; i++) {
				handleDatum(data[i].id, data[i].type, data[i].flags ? data[i].flags : null, null, data[i].value, time, dataReloader);
			}
			if (!updateOnly && navctx.active.currFieldIndex === -1) {
				G.nav.navPageInit(xmlPage);
			}
		}
	};
};

// ----
var G;
// ----


function readConfiguration() {
	var configs, i, key, value;

	// Default configuration
	configuration.etu_language = "en_US";
	configuration.controller_language = "en_US";
	configuration.backlight_active = "90";
	configuration.backlight_idle = "50";

	configs = document.cookie.split(";");
	for (i = 0; i < configs.length; i++) {
		key = configs[i].substring(0, configs[i].indexOf("=")).replace(/^\s*/, "");
		value = configs[i].substring(configs[i].indexOf("=") + 1).replace(/^\s*/, "");
		//console.log("Conf: " + key + "=" + value);
		configuration[key] = value;
	}
	configuration.saved_controller_language = configuration.controller_language;
}

function localisationLoader(fname, language, appendArray) {
	var response, xmlHttp, lines, i, parts;

	xmlHttp = new XMLHttpRequest();
	xmlHttp.open("GET", fname + "_" + language + ".properties", false);
	xmlHttp.onreadystatechange = function () {
		if (this.readyState === XMLHttpRequest.DONE) {
			response = this.responseText;
			lines = response.split("\r\n");
			if (lines.length === 1) {
				lines = response.split("\n");
			}
			for (i = 0; i < lines.length; i++) {
				if (lines[i].length === 0 || lines[i][0] !== '#') {
					parts = lines[i].split("=", 2);
					if (parts.length === 2) {
						appendArray[parts[0]] = eval("'" + parts[1].replace(/'/, "\\u0027") + "'");
					}
				}
			}
		}
	};
	xmlHttp.send(null);
}

var TRIM_UNIT = /(.*)unit\//;
function startBrowserEngine(rt, up) {
	document.onclick = function () {
		sec_ping();
	};
	
	G = {
		view: cpt_view(),
		nav: cpt_nav()
	};
	readConfiguration();
	reloadTime = rt;
	localisationLoader("engine/res", configuration.controller_language, engineTranslationMap);


	controllerUnitPath = up;
	initMainCont(up, true);

//alert("startBrowserEngine...");
	cptview = pageview("cpt_view", "engine/");
	cptview.load("p_cpt_view");
	cptview.start();

	focus();
	init_sec();
}

function sendLocalValueSync(wrtFileName, value) {
	var xmlHttp, elem;
	
	xmlHttp = new XMLHttpRequest();
	xmlHttp.open("POST", wrtFileName, false);
	xmlHttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	xmlHttp.send('tag2=' + 'data=' + value);
	return xmlHttp.status;
}

function checkXML(str) {
	var d, l, parser, errorNs, element, err, st, xmlDoc;

	if (typeof ActiveXObject !== "undefined") {
		d = new ActiveXObject("MSXML.DomDocument");
		l = d.loadXML(str);
		if (!l) {
			console.log('Line: ' + d.parseError.line + ', Column: ' + d.parseError.linepos + '\r\n' + d.parseError.reason + d.parseError.srcText);
		}
	} else if (typeof XMLHttpRequest !== "undefined") {
		parser = new DOMParser();
		xmlDoc = parser.parseFromString(str, 'application/xml');
		errorNs = 'http://www.mozilla.org/newlayout/xml/parsererror.xml';
		element = xmlDoc.documentElement;
		err = { errorCode: 0};
		if (element.nodeName === 'parsererror' && element.namespaceURI === errorNs) {
			err.errorCode = 1;
			st = element.getElementsByTagNameNS(errorNs, 'sourcetext')[0];
			if (st !== null) {
				err.srcText = st.firstChild.data;
			}
			err.reason = element.firstChild.data;
		}
		if (err.errorCode !== 0) {
			console.log(err.reason + '\r\n' + err.srcText);
		}
	}
}


function incrementUptime() {
	sendLocalValueSync("engine/w_inc_acc_uptime.cgi", null);
}

function handleFooterData(xmlRes, time) {
	var alarmstr, testmodestr, ipstr, i, tagData, atId, testmode, ips, alarmType, testmodes, alarms;

	if (xmlRes === null) {
		return;
	}

	alarmstr = null;
	testmodestr = null;
	ipstr = null;

	for (i = 0; i < xmlRes.getElementsByTagName('data').length; i++) {
		tagData = xmlRes.getElementsByTagName('data')[i];
		atId = tagData.getAttribute('id');
		switch (atId) {
		case "disc_alarm":
			if (tagData.childNodes[0]) {
				alarmstr = tagData.childNodes[0].nodeValue;
			}
			break;
		case "disc_06":
			if (tagData.childNodes[0]) {
				testmodestr = tagData.childNodes[0].nodeValue;
			}
			break;
		case "disc_ip":
			if (tagData.childNodes[0]) {
				ipstr = tagData.childNodes[0].nodeValue;
			}
			break;
		}
	}

	testmode = 0;
	if (ip !== null && ipstr !== null && testmodestr !== null) {
		testmodes = testmodestr.split(',');
		ips = ipstr.split(',');
		for (i = 0; i < testmodes.length; i++) {
			if (ips[i] === ip) {
				testmode = testmodes[i] & 32;
				break;
			}
		}
	}
	
	alarmType = 0;
	if (alarmstr !== null) {
		alarms = alarmstr.split(',');
		for (i = 0; i < alarms.length; i++) {
			if (alarmType === 0 && alarms[i] === "1") {
				alarmType = 1;
			} else if (alarms[i] === "2") {
				alarmType = 2;
				break;
			}
		}
		document.getElementById('alarmstatus').innerHTML = alarmType === 1 ? "&#9872;" : alarmType === 2 ? "&#9888;" : "&#8195;";
		document.getElementById('testmode').innerHTML = testmode === 0 ? "" : "Test mode ON";
	}
}

// Initialize ajax-part - called first
function startEtuEngine(rt, up) {
	G = {
		view: etu_view(),
		nav: etu_nav()
	};
	setInterval(incrementUptime, 1000 * 60 * 60);
	sendLocalValueSync("engine/w_inc_boots.cgi", null);

	readConfiguration();
	reloadTime = rt;
	localisationLoader("engine/res", configuration.etu_language, engineTranslationMap);

	subscribePoller("engine/discovery.cgi", handleFooterData, 2000);
	initMainCont(up, false);

	updateHeader("", "", null);
	focus();
	etu_display_ping();
	init_sec();

	if (configuration.upgraded === "yes") {
		document.cookie = "upgraded=no; expires=31-Dec-2037 23:59:59 GMT";
		showPopup('p_information', null, {'cancel': [null, null]});
		document.getElementById('ajax_information_msg').innerHTML = i18n.getText("application_upgrade_complete");
	}
}

function updateHeader(nodeNo, nodeName, nodeIp) {
	var element;
	
	element = document.getElementById('engine_nodename');

	if (!element) {
		return;
	}

	if (!!nodeIp) {
		element.innerHTML = "" + nodeName;
	} else  {
		element.innerHTML = i18n.getText("network_discovery");
	}
}

var selectedMenuElement = null;
function gotoPage(fname, up, pgs) {
	var newPageIndex, i, unsub, menuelement, newmainview;
	
	if (mainview) {
		mainview.stop();
	}
	try {

		if (!pgs) pgs = pages;

		for (i = 0; i < pgs.length; i++) {
			if (pgs[i].name === fname) {
				newPageIndex = i;
				break;
			}
		}
		if (selectedMenuElement) {
			selectedMenuElement.className = "bullet";
		}
		menuelement = document.getElementById("pagenr" + newPageIndex);
		if (menuelement) {
			menuelement.className = "bullet selected";
			selectedMenuElement = menuelement;
		}

		newmainview = pageview('cont', up);

		navctx.pop();
		navctx.createNewAndActivate();

		if (newmainview.load(fname) === null) {
			navctx.undoPop();
			menuelement = document.getElementById("pagenr" + currPageIndex);
			if (menuelement) {
				menuelement.className = "bullet selected";
			}
			return false;
		}

		G.nav.focusPage();

		currPageIndex = newPageIndex;

		mainview = newmainview;
		return true;
	} finally {
		if (mainview) {
			mainview.start();
		}
	}
}

function initMainCont(up, contr) {
	var unsub, xmlConf, newPages = [], language;
	if (mainview) {
		mainview.stop();
	}

	unitInit();
	configFile = up + 'xfrm/config';

	xmlConf = confLoader(contr, newPages);

	translationMap = [];
	if (contr) {
		if (!conf[contr].languages[configuration.saved_controller_language]) {
			configuration.controller_language = "en_US";
		} else {
			configuration.controller_language = configuration.saved_controller_language;
		}
		localisationLoader(up + "res", configuration.controller_language, translationMap);
	} else {
		configuration.controller_language = configuration.saved_controller_language;
	}

	if (xmlConf === null || homePage === -1) {
			mainview.start();
			return;
	}
	if (!gotoPage(newPages[homePage].name, up, newPages)) {
//		mainview.start();
		if (mainview) mainview.start(); // LALE
		return;
	}
	unitPath = up;
	pages = newPages;
	isOnController = contr;
}

var pollers = [];
function Poller(dataFile, callback, updateInterval) {
	var callbacks, timeoutTimer, paused, fetchPage, executeCallbacks;

	callbacks = {};
	timeoutTimer = null;
	paused = false;

	this.addCallback = function (callback) {
		callbacks[callback] = callback;

		return function () {
			var last, dummy;

			delete callbacks[callback];
			last = true;
			for (dummy in callbacks) { // TODO Must be an easier way...
				last = false;
				break;
			}
			if (last) {
				clearTimeout(timeoutTimer);
				delete pollers[dataFile];
			}
		};
	};
	this.unPause = function () {
		paused = false;
		if (timeoutTimer == null) {
			timeoutTimer = setTimeout(fetchPage, updateInterval ? updateInterval : reloadTime);
		}
	};
	this.pause = function () {
		paused = true;
		clearTimeout(timeoutTimer);
		timeoutTimer = null;
	};

	executeCallbacks = function (xmlRes, senttime) {
		var last, callback;

		if (paused) {
			return;
		}

		last = true;
		try {
			for (callback in callbacks) {
				callbacks[callback](xmlRes, senttime);
				last = false;
			}
		} finally {
			if (!last && !paused) {
				if (timeoutTimer == null) {
					timeoutTimer = setTimeout(fetchPage, updateInterval ? updateInterval : reloadTime);
				}
			}
		}
	};

	fetchPage = function () {
		timeoutTimer = null;
		if (callbacks) {
			dataLoader(dataFile, executeCallbacks);
		}
	};

	this.poll_now = function () {
		clearTimeout(timeoutTimer);
		timeoutTimer = setTimeout(fetchPage, 0);
	};

	this.poll_now();
}
// Only the first requester can choose interval. If no inverval is given a global will be used
function subscribePoller(dataFile, callback, updateInterval) {
	var poller = pollers[dataFile];
	if (!poller) {
		poller = new Poller(dataFile, callback, updateInterval);
		pollers[dataFile] = poller;
	} else {
		poller.poll_now();
	}
	return poller.addCallback(callback);
}
function pausePollers(pause) {
	var poller;

	for (poller in pollers) {
		if (pause) {
			pollers[poller].pause();
		} else {
			pollers[poller].unPause();
		}
	}
}

// Load data file and send control to unit-part.
// 'null' as callback will make sync call and return result
function dataLoader(dataFile, callback) {
	var xmlRes, xmlHttp, fname, element, senttime;

	xmlRes = null;
	xmlHttp = new XMLHttpRequest();
	fname = dataFile; // +'?'+new Date().getTime()
	xmlHttp.open("GET", fname, callback ? true : false);
	element = document.getElementById("hb");
	if (element) {
		element.style.visibility = "visible";
	}
	xmlHttp.onreadystatechange = function () {
		if (this.readyState === XMLHttpRequest.DONE) {
			xmlRes = this.responseXML;
			if (!xmlRes) {
				console.log("invalid response: " + this.responseText + " for: " + fname);
			}// checkXML(this.responseText);}
			if (callback) {
				callback(xmlRes, senttime);
			}
			element = document.getElementById("hb");
			if (element) {
				element.style.visibility = "hidden";
			}
		}
	};
	senttime = new Date().getTime();
	xmlHttp.send(null);
	return xmlRes;
}


function applyXslt(xmlIn, xmlXslt, target) {
	var ht, xsltProcessor, resultDocument;

//alert("enter applyXslt...");
	if (xmlXslt !== null)
	{
		if (!target) {
alert("applyXslt return false");
			return false;
		}
		// IE
		if (window.ActiveXObject) {
			ht = xmlIn.transformNode(xmlXslt);
			target.innerHTML = ht;
		}
		// Mozilla, Firefox, Opera, etc.
		else if (document.implementation && document.implementation.createDocument) {
			xsltProcessor = new XSLTProcessor();
			try {
				xsltProcessor.importStylesheet(xmlXslt);
				resultDocument = xsltProcessor.transformToFragment(xmlIn, document);
			} catch (e) {}
			while (target.firstChild) {
				target.removeChild(target.firstChild);
			}
			target.appendChild(resultDocument);
		}
	}

//alert("exit applyXslt");

}

var nodeInfoPoller = null;
function populateCptView() {
	if (!nodeInfoPoller) {
		nodeInfoPoller = subscribePoller(controllerUnitPath + "r_node_info.xml", cptview.handlePollData, 2000);
	}
	populateLanguageVal(cptview, "cpt_language", true);
	populateCptPageMenu(pages);
	menuelement = document.getElementById("pagenr" + currPageIndex);
	if (menuelement) {
		menuelement.className = "bullet selected";
		selectedMenuElement = menuelement;
	}


		setLoginLevels = function () {
			var level, i, item, optds, optdv, tagVal;

			tagVal = cptview.getValTagById("cpt_sec_level");

					optds = i18n.getText("none");
					optdv = "0";
					for (item in security.getLevels()) {
						if (typeof item === 'string') {
							level = security.getLevelInfo(item);
							if (level.name) {
								if (level.hidden) { 
									continue;
								}
								if (optdv.length !== 0) {
									optds += ",";
									optdv += ",";
								}
								optds += i18n.getText(level.name);
								optdv += item;
							}
						}
					}
					tagVal.setAttribute("optds", optds);
					tagVal.setAttribute("optdv", optdv);
		};
	setLoginLevels();
	cptview.handleData(
		[
			{'id': 'cpt_login', 'type': 'int', 'value': 1},
			{'id': 'cpt_logout', 'type': 'int', 'value': 1},
			{'id': 'cpt_language', 'type': 'str', 'value': configuration.controller_language}
		], new Date().getTime());
}

function selectLoginLevel(value) {
	if (value === "0") {
		security.logout();
		populateCptView();
	} else {
		showLoginPopup(value,populateCptView,populateCptView,'sec_password');
	}
}

function canvasPossible(){ 
    var isOpera = !!window.opera || navigator.userAgent.indexOf(' OPR/') >= 0;
    // Opera 8.0+ (UA detection to detect Blink/v8-powered Opera)
    var isFirefox = typeof InstallTrigger !== 'undefined';   // Firefox 1.0+
    var isSafari = Object.prototype.toString.call(window.HTMLElement).indexOf('Constructor') > 0;
    // At least Safari 3+: "[object HTMLElementConstructor]"
    var isChrome = !!window.chrome && !isOpera;              // Chrome 1+
    var isIE = /*@cc_on!@*/false || !!document.documentMode;   // At least IE6

    /*var output = 'Detecting browsers by ducktyping:<hr>';
    output += 'isFirefox: ' + isFirefox + '<br>';
    output += 'isChrome: ' + isChrome + '<br>';
    output += 'isSafari: ' + isSafari + '<br>';
    output += 'isOpera: ' + isOpera + '<br>';
    output += 'isIE: ' + isIE + '<br>';
    document.body.innerHTML = output;
		console.log("isChrome:" + isChrome);
		console.log("isFirefox:" + isFirefox);
		console.log("isSafari:" + isSafari);
		console.log("isOpera:" + isOpera);
		console.log("isIE:" + isIE);*/

		if (isChrome || isFirefox || isSafari || isOpera) return true;
		else return false;
}

// Load configuration file -> xmlConf
function confLoader(isOnController, pages) {
	var xmlRes, xmlHttp, c, i, cond, atHome, tagPage, technical, technicalTags, bitwriteTag, bitwrite, canstoreretrieve, canstoreretrieveTag, levels, levelTags, languages, languageTags, versionTags, confLanOk, lanName, lanCode;

	// TODO Error handling from broken config file

  doCanvas = canvasPossible();
	
	console.log("showDyGraph " + doCanvas);
	
	xmlRes = null;
	xmlHttp = new XMLHttpRequest();
	xmlHttp.open("GET", configFile + ".xml", false);
	xmlHttp.onreadystatechange = function () {
		if (this.readyState === XMLHttpRequest.DONE) {
			xmlRes = this.responseXML;
			if (xmlRes === null) {
				checkXML(this.responseText);
				return null;
			}

			c = 0;
			for (i = 0; i < xmlRes.getElementsByTagName('page').length; i++) {
				tagPage = xmlRes.getElementsByTagName('page')[i];
				try {
					if (tagPage.getAttribute('cond')) {
						cond = tagPage.getAttribute('cond');
						if (!eval(cond)) {
							continue;
						}
					}
				} catch (ex) {
					console.log("Error when evaluating 'cond' statement: " + ex);
				}
				pages[c] = {};
				pages[c].name = tagPage.getAttribute('name');
				pages[c].title = tagPage.getAttribute('title');
				pages[c].subtitle = tagPage.getAttribute('subtitle');
				pages[c].hidden = tagPage.getAttribute('hidden');
				//pages[c].canvasgraphics = tagPage.getAttribute('canvasgraphics');
				

				if (!doCanvas) {
				  if (pages[c].name == "p_statistics_3") {
					  pages[c].hidden = "true";
					}
					if (pages[c].name == "p_scope_capture") {
					  pages[c].hidden = "true";
					}
					if (pages[c].name == "p_scope_view") {
					  pages[c].hidden = "true";
					}
				}

				
				atHome = tagPage.getAttribute('home');
				if (atHome === 'yes') {
					homePage = c;
				}
				c++;
			}

			for (i = 0; i < xmlRes.getElementsByTagName('helppage').length; i++) {
				tagPage = xmlRes.getElementsByTagName('helppage')[i];
				helppages[i] = {};
				helppages[i].name = tagPage.getAttribute('name');
				helppages[i].title = tagPage.getAttribute('title');
			}

			levels = [];
			levelTags = xmlRes.getElementsByTagName('level');
			for (i = 0; levelTags && i < levelTags.length; i++) {
				levels[levelTags[i].getAttribute('id')] =
				{
					id: parseInt(levelTags[i].getAttribute('id'), 10),
					name: levelTags[i].getAttribute('name'),
					pw: levelTags[i].getAttribute('pw'),
					timeout: parseInt(levelTags[i].getAttribute('timeout'), 10),
					autoconf: levelTags[i].getAttribute('autoconf') === "true",
					hidden: levelTags[i].getAttribute('hidden') === "true",
					seehidden: levelTags[i].getAttribute('seehidden') === "true"
				};

			}
			security.setLevels(levels);

			technical = [];
			technicalTags = xmlRes.getElementsByTagName('technical');
			bitwrite = null;
			if (technicalTags.length > 0) {
				bitwriteTag = technicalTags[0].getElementsByTagName('bitwrite');
				if (bitwriteTag.length > 0) {
					bitwrite = bitwriteTag[0].childNodes[0].nodeValue;
				}
				canstoreretrieveTag = technicalTags[0].getElementsByTagName('canstoreretrieve');
				if (canstoreretrieveTag.length > 0) {
					canstoreretrieve = canstoreretrieveTag[0].childNodes[0].nodeValue;
				}
			}
			conf[isOnController].bitwrite = bitwrite === "direct" ? "direct" : "rmw";
			conf[isOnController].canstoreretrieve = canstoreretrieve === "true" ? true : false;

			languages = [];
			languageTags = xmlRes.getElementsByTagName('language');
			for (i = 0;languageTags && i < languageTags.length; i++) {
				lanName = languageTags[i].getAttribute("name");
				lanCode = languageTags[i].childNodes[0].nodeValue;
				languagesTranslationMap[lanCode] =
					eval("'" + lanName.replace(/'/, "\\u0027") + "'");
				languages[lanCode] = lanCode;
			}
			conf[isOnController].languages = languages;

			versionTags = xmlRes.getElementsByTagName('version');
			if (!versionTags) {
				console.log("didn't find tag");
			}
			conf[isOnController].version = versionTags[0].childNodes[0].nodeValue;
		}
	};
	xmlHttp.send(null);
	if (xmlRes !== null) {
		xmlConf = xmlRes;
	}
	return xmlRes;
}

function convertValueForWriting(value, dType, xatSize) {
	var convertedValue, c, parts, i, seconds, hasDays;

	switch (dType) {
	case 'str':
		//convertedValue = '';
		//for (c = 0; c < value.length; c++) {
		//	if (c !== 0) {
		//		convertedValue += "+";
		//	}
    //
		//	convertedValue += value.charCodeAt(c);
		//}
		//for (; c < xatSize; c++) {
		//	convertedValue += "+";
		//	convertedValue += " ".charCodeAt(0);
		//}
		//value = convertedValue;
		break;
	case 'ip':
		value = value.replace(/(\.|^)0{1,2}(\d)/g, "$1$2");
		break;
	case 'dte':
		// TODO Handle localized dates
		parts = value.split('-');
		value = "" + (parseInt(parts[0], 10) - 1900) + "+" + parts[1] + "+" + parts[2];
		break;
  case 'tme':
		parts = value.split(':');
		i = 0;
		seconds = 0;
		hasDays = 0;
    //calculating second of everything
		if (parts[i].length == 3) { // Days
			hasDays = 1;
			seconds += (parseInt(parts[i++], 10) % 367) * 24;
		}
		for (c = 0; c < 3; c++) {
			if (parts[i]) {
				seconds += parseInt(parts[i++], 10);
			}
			if (c !== 2) {
				seconds *= 60;
			}
		}
    //split it up
		value = "";
		if (hasDays) {
			value = ""  + Math.floor(seconds / 24 / 60 / 60) + "+";
		}
		seconds = seconds % (24 * 60 * 60);

		value += Math.floor(seconds / 60 / 60) + "+";
		seconds = seconds % (60 * 60);

		value += Math.floor(seconds / 60);

		if (!!parts[hasDays + 2]) {
			seconds = seconds % 60;
			value += "+" + seconds;
		}
		break;
  case 'tma':
		parts = value.split(':');
		i = 0;
		seconds = 0;
		hasDays = 0;
    //calculating second of everything
		if (parts[i].length == 3) { // Days
			hasDays = 1;
			seconds += (parseInt(parts[i++], 10) % 367) * 24;
		}
		for (c = 0; c < 3; c++) {
			if (parts[i]) {
				seconds += parseInt(parts[i++], 10);
			}
			if (c !== 2) {
				seconds *= 60;
			}
		}
    //split it up
		value = "";
		if (hasDays) {
			value = ""  + Math.floor(seconds / 24 / 60 / 60) + "+";
		}
		seconds = seconds % (24 * 60 * 60);

		value += Math.floor(seconds / 60 / 60) + "+";
		seconds = seconds % (60 * 60);

		value += Math.floor(seconds / 60);

		if (!!parts[hasDays + 2]) {
			seconds = seconds % 60;
			value += "+" + seconds;
		}
		break;
	}
	return value;
}

function updateValueSyncUnit(wrtFileName, value, element, isBitvalue, type, dType, xatSize, tagName) {
	value = convertValueForWriting(value, dType, xatSize);

	function sendValueSync(wrtFileName, value, element) {
		var xmlHttp, elem;
	
		xmlHttp = new XMLHttpRequest();
    wrtFileName = "dummy";
		wrtFileName = unitPath + wrtFileName; 

		xmlHttp.open("POST", wrtFileName + '.htm', false);
    //xmlHttp.open("POST", 'tst.htm', false);
		xmlHttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
		if (element !== null) {
			elem = element;
			xmlHttp.onreadystatechange = function () {
				// TODO Must handle timeouts and other errors
				if (this.readyState === XMLHttpRequest.DONE) {
					elem.setAttribute("lastupdatetime", new Date().getTime());
				}
			};
		}
		xmlHttp.send('type=' + dType + ' ' +'tag=' + tagName + ' ' + 'data=' + value);
		return xmlHttp.status;
	}

	function sendBitValueSync(wrtFileName, value, element) {
		var fname, xmlHttp, xmlRes, val, elem;

		function handleBitData(bitData, wrtFileName, value, element) {
			var tags, bitnr, data, writeValue;

			if (typeof value === 'string') {
				value = parseInt(value, 10);
			}
			tags = bitData.getElementsByTagName('data');
			if (tags.length !== 1) {
				// TODO how to handle?
				console.log("Broken bit response");
				return;
			}
			bitnr = tags[0].getAttribute('bit');
			data = tags[0].childNodes[0].nodeValue;
			writeValue = (~(1 << bitnr)) & data | (value << bitnr);
			sendValueSync(wrtFileName, writeValue, element);
		}

		elem = element;
		val = value;
		fname = unitPath + 'bit_' + wrtFileName + '.xml'; //+'?'+new Date().getTime();
		xmlHttp = new XMLHttpRequest();
		xmlHttp.open("GET", fname, true);
		xmlHttp.onreadystatechange = function () {
			if (this.readyState === XMLHttpRequest.DONE) {
				xmlRes = this.responseXML;
				if (xmlRes === null) {
					checkXML(this.responseText);
					return null;
				}
				handleBitData(xmlRes, wrtFileName, val, elem);
			}
		};
		xmlHttp.send(null);
	}

	if (isBitvalue && conf[isOnController].bitwrite === "rmw") {
		sendBitValueSync(wrtFileName, value, element);
	} else {
		sendValueSync(wrtFileName, value, element);
	}
}
var updateValueSync = updateValueSyncUnit;

function listFilesSettings(keepFileName) {
	var target, targets, responseText, responseStatus, xmlHttp, fname, element;

	targets = ["local", "usb"];
	target = document.getElementById("ajax_settings_memory").getAttribute('lastval').replace(/ /g,"");

	// TOOD Error checking so that error text isn't shown
	responseText = null;
	responseStatus = 0;
	xmlHttp = new XMLHttpRequest();
	fname = 'engine/settings.php?cmd=list&target=' + targets[parseInt(target, 10)]; // +'&'+new Date().getTime();
	xmlHttp.open("GET", fname, false);
	element = document.getElementById("hb");
	if (element) {
		element.style.visibility = "visible";
	}
	xmlHttp.onreadystatechange = function() {
		if (this.readyState === XMLHttpRequest.DONE) {
			responseStatus = this.status;
			responseText = this.responseText;
			if (element) {
				element.style.visibility = "hidden";
			}
		}
	};
	xmlHttp.send(null);

	if (!keepFileName) {
		popupview.handleData([
				{'id': 'file_name','type': 'str','value': ""},
				{'id': 'ok', 'type': 'int', 'value': 0}
				], new Date().getTime());
	}

	if (responseStatus === 503) {
		document.getElementById('ajax_settings_msg').innerHTML = i18n.getText("no_usb_found");
		popupview.handleData([{'id': 'settings_file', 'type': 'str', 'value': "" }], new Date().getTime());
	} else {
		document.getElementById('ajax_settings_msg').innerHTML = "";
		popupview.handleData([{'id': 'settings_file', 'type': 'str', 'value': responseText }], new Date().getTime());
	}
}

function storeSettingsToFile() {
	var targets, filename, target, url, responseText, xmlHttp, fname, element;

	targets = ["local", "usb"]; // TODO Duplicated in listFilesSettings
	filename = document.getElementById("ajax_file_name").getAttribute('lastval').replace(/ /g,"");
	target = document.getElementById("ajax_settings_memory").getAttribute('lastval').replace(/ /g,"");

	url = controllerUnitPath.substr(controllerUnitPath.search(/http:/)) + "read_all.xml";

	responseText = null;
	xmlHttp = new XMLHttpRequest();
	fname = 'engine/settings.php?cmd=save&target=' + targets[parseInt(target, 10)] + '&filename=' + filename + '.xml&url=' + url; // + '&' +new Date().getTime();
	xmlHttp.open("GET", fname, false); // TODO Should be POST?!
	element = document.getElementById("hb");
	if (element) {
		element.style.visibility = "visible";
	}
	xmlHttp.onreadystatechange = function (){
		if (this.readyState === XMLHttpRequest.DONE){
			responseText = this.responseText;
			if (element) {
				element.style.visibility="hidden";
			}
		}
	};
	xmlHttp.send(null);

	// Check fail or success and inform user
	return true;
}

function storeSettings() {
	showPopup('p_save_settings',
			[
			{'id': 'settings_file', 'type': 'str', 'value': ""},
			{'id': 'cancel', 'type': 'int', 'value': 1},
			{'id': 'ok', 'type': 'int', 'value': 1},
			{'id': 'file_name', 'type': 'str', 'value': currNodeName.replace(/ /g,"")},
			{'id': 'settings_memory', 'type': 'int', 'value': 0}
			],
			{'cancel': [null, null],
			'ok': [storeSettingsToFile, null],
			'w_settings_memory': [function () {
				listFilesSettings(true);
			}, null]
			}, null);
	listFilesSettings(true);
}

function deleteSettings() {
	showPopup('p_delete_settings',
			[
			{'id': 'settings_file', 'type': 'str', 'value': ""},
			{'id': 'cancel', 'type': 'int', 'value': 1},
			{'id': 'ok','type': 'int', 'value': 0},
			{'id': 'settings_memory','type': 'int', 'value': 0}
			],
			{'cancel': [null, null],
			'ok': [deleteSettingsFile, null],
			'w_settings_memory': [listFilesSettings, null]
			}, null);
	listFilesSettings();
}

function deleteSettingsFile() {
	var targets, filename, target, responseText, xmlHttp, fname, element;

	targets = ["local", "usb"]; // TODO Duplicated in listFilesSettings
	filename = document.getElementById("ajax_file_menu_items").getAttribute("lastval").replace(/\.xml/,"");
	target = document.getElementById("ajax_settings_memory").getAttribute('lastval').replace(/ /g,"");

	responseText = null;
	xmlHttp = new XMLHttpRequest();
	fname = 'engine/settings.php?cmd=delete&target=' + targets[parseInt(target, 10)] + '&filename=' + filename + '.xml'; // + '&' +new Date().getTime();
	xmlHttp.open("GET", fname, false); // TODO Should be POST?!
	element = document.getElementById("hb");
	if (element) {
		element.style.visibility = "visible";
	}
	xmlHttp.onreadystatechange = function () {
		if (this.readyState === XMLHttpRequest.DONE) {
			responseText = this.responseText;
			if (element) {
				element.style.visibility = "hidden";
			}
		}
	};
	xmlHttp.send(null);

	// Check fail or success and inform user
	return true;
}

function retrieveSettings() {
	showPopup('p_load_settings',
			[
			{'id': 'settings_file', 'type': 'str', 'value': ""},
			{'id':'cancel', 'type': 'int', 'value': 1},
			{'id': 'ok', 'type': 'int', 'value': 0}, 
			{'id': 'settings_memory', 'type': 'int', 'value': 0}
			],
			{'cancel': [null, null],
			'ok': [retrieveSettingsFromFile, null],
			'w_settings_memory': [listFilesSettings, null]
			}, null);
	listFilesSettings();
}

function retrieveSettingsFromFile() {
	var targets, filename, target, xmlRes, responseText, element, variables, xmlHttp, bit_variables, requestData, SEND_LIMIT, i, data, size, flags, value, bits, bitmask, currentBits, c, dataToAdd, ok;

	targets = ["local", "usb"]; // TODO Duplicated in listFilesSettings
	filename = document.getElementById("ajax_file_menu_items").getAttribute("lastval").replace(/\.xml/,"");
	target = document.getElementById("ajax_settings_memory").getAttribute('lastval').replace(/ /g,"");
	xmlRes = null;
	textRes = null;

	responseText = null;
	xmlHttp = new XMLHttpRequest();
	fname = 'engine/settings.php?cmd=load&filename=' + filename + '.xml&target=' + targets[parseInt(target, 10)]; // +'&'+new Date().getTime();
	xmlHttp.open("GET", fname, false);
	element = document.getElementById("hb");
	if (element) {
		element.style.visibility = "visible";
	}
	xmlHttp.onreadystatechange = function () {
		if (this.readyState === XMLHttpRequest.DONE) {
			xmlRes = this.responseXML;
			textRes = this.responseText;
			if (xmlRes === null) {
				checkXML(this.responseText);
				return null;
			} // TODO show error to user

			if (element) {
				element.style.visibility = "hidden";
			}
		}
	};
	xmlHttp.send(null);
	variables = xmlRes.getElementsByTagName('data');

	responseText = null;
	xmlHttp = new XMLHttpRequest();
	xmlHttp.open("GET", controllerUnitPath + 'bit_write_all.xml', false);
	element = document.getElementById("hb");
	if (element) {
		element.style.visibility = "visible";
	}
	xmlHttp.onreadystatechange = function () {
		if (this.readyState === XMLHttpRequest.DONE) {
			xmlRes = this.responseXML;
			textRes = this.responseText;
			if (xmlRes === null) {
				checkXML(this.responseText); 
				return null;
			} // TODO show error to user

			if (element) {
				element.style.visibility = "hidden";
			}
		}
	};
	xmlHttp.send(null);
	bit_variables = xmlRes.getElementsByTagName('data');

	requestData = "";
	SEND_LIMIT = 1000; // Not strict limit
	for(i = 0; i < variables.length ; i++){

		data = variables[i];

		if (data.childNodes.length>0) {
			size = data.getAttribute("size");
			flags = data.getAttribute("flags");
			if (!flags) {
				value = convertValueForWriting(data.childNodes[0].nodeValue, data.getAttribute("type"), size ? size : 0);
			} else {
				bits = flags.split(",");
				bitmask = 0;

				for (c = 0; c < bits.length; c++) {
					if (bits[c].length > 0) {
						bitmask  = bitmask | (1 << c);
					}
				}

				currentBits = null;
				for (c = 0; c < bit_variables.length; c++) {
					if (bit_variables[c].getAttribute("varw") === data.getAttribute("varw")) {
						currentBits = parseInt(bit_variables[c].childNodes[0].nodeValue, 10);
						break;
					}
				}
				if (currentBits === null) {
					console.log("Could not find old bits!");
					continue;
				}
				value = (currentBits & ~bitmask) | (parseInt(data.childNodes[0].nodeValue, 10) & bitmask);
			}
			
			dataToAdd = data.getAttribute("varw") + "=" + value + "&";
			requestData += dataToAdd;
			if (!((i < (variables.length - 1)) && (requestData.length + dataToAdd.length <= SEND_LIMIT))) {
				ok = false;
				while (!ok) {
					try {
						// TODO Test if same XMLHttpRequest can be reused for multiple .send
						xmlHttp = new XMLHttpRequest();
						xmlHttp.open("POST", controllerUnitPath + 'write_all.htm', false);
						xmlHttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
						xmlHttp.onreadystatechange = function () {
							// TODO Must handle timeouts and other errors
							if (this.readyState === XMLHttpRequest.DONE) {
							}
						};
						xmlHttp.send(requestData);
						ok = true;
					} catch (e) {
						console.log("Got exception: " + e + ", retrying.");
					}
				}
				requestData = "";
			}
		}
	}

	//console.log("r: " + requestData);
	return true;
}

function listFiles(target) {
	// TOOD Error checking so that error text isn't shown
	var responseText, responseStatus, xmlHttp, fname;

	responseText = null;
	responseStatus = 0;
	xmlHttp = new XMLHttpRequest();
	fname = 'engine/settings.php?cmd=list&target=' + target;
	xmlHttp.open("GET", fname, false);
	var element = document.getElementById("hb");
	if (element) {
		element.style.visibility = "visible";
	}
	xmlHttp.onreadystatechange = function () {
		if (this.readyState === XMLHttpRequest.DONE){
			responseStatus = this.status;
			responseText = this.responseText;
			if (element) {
				element.style.visibility="hidden";
			}
		}
	};
	xmlHttp.send(null);

	if (responseStatus === 503) {
		document.getElementById('ajax_file_msg').innerHTML = i18n.getText("no_usb_found");
		popupview.handleData([{'id': 'file_list', 'type': 'str', 'value': "" }], new Date().getTime());
	} else {
		popupview.handleData([{'id': 'file_list', 'type': 'str', 'value': responseText }], new Date().getTime());
	}
}

function fileSaveItemSelected(tr) {
	var filename;

	// TODO IE6 doesn't support outline
	tr.style.backgroundColor = '';
	tr.style.outline = '';

	filename = tr.firstChild.firstChild.getAttribute("lastval").replace(/\.xml/,"");

	popupview.handleData([{'id':'file_name','type':'str','value':filename }], new Date().getTime());
	popupview.handleData([{'id':"ok",'type':'int','value':1 }], new Date().getTime());

	moveToField('file_name');
	navctx.active.currLst = null;
}

function fileItemSelected(tr, jumpFieldName) {
	var value, filename;

	// TODO IE6 doesn't support outline
	tr.style.backgroundColor = '';
	tr.style.outline = '';

	value = tr.firstChild.firstChild.getAttribute("lastval");
	tr.parentNode.parentNode.parentNode.setAttribute("lastval", value);
	filename = value.replace(/\.xml/,"");

	popupview.handleData([{'id': 'file_name', 'type': 'str', 'value': filename}], new Date().getTime());
	popupview.handleData([{'id': "ok", 'type': 'int', 'value': 1}], new Date().getTime());

	moveToField(jumpFieldName);
	navctx.active.currLst = null;
}

// --------------------------------------------------


(function (){
	var xmlHttp=window.XMLHttpRequest;
	var bGecko=!!window.controllers,bIE=window.document.all && !window.opera;

	function XmlHttpReq(){
		this._object=xmlHttp ? new xmlHttp : new window.ActiveXObject("Microsoft.XMLHTTP");
		this._listeners=[];
	};

	if(bGecko && xmlHttp.wrapped)	XmlHttpReq.wrapped=xmlHttp.wrapped; // Firefox with Firebug

	XmlHttpReq.UNSENT=0;
	XmlHttpReq.OPENED=1;
	XmlHttpReq.HEADERS_RECEIVED=2;
	XmlHttpReq.LOADING=3;
	XmlHttpReq.DONE=4;
	XmlHttpReq.prototype.readyState=XmlHttpReq.UNSENT;
	XmlHttpReq.prototype.responseText='';
	XmlHttpReq.prototype.responseXML=null;
	XmlHttpReq.prototype.status=0;
	XmlHttpReq.prototype.statusText='';
	XmlHttpReq.prototype.onreadystatechange=null;
	XmlHttpReq.onreadystatechange=null;
	XmlHttpReq.onopen=null;
	XmlHttpReq.onsend=null;
	XmlHttpReq.onabort=null;
	XmlHttpReq.prototype.open=function(sMethod,sUrl,bAsync,sUser,sPassword){

	if(arguments.length < 3) bAsync=true;
	this._async=bAsync; // Fix Gecko bug with missing readystatechange in synchronous requests

	var RequestObj=this,nState=this.readyState; // Onreadystatechange handler

	// IE - memory leak on page unload
	if(bIE){
		// Add unique number to make sure IE6 won't cache. WebKit don't need it
		// and will trigger a memory leak if used.
		sUrl += ((sUrl.indexOf('?') === -1)?"?":"&") + new Date().getTime();

		var fOnUnload=function(){
			if(RequestObj._object.readyState != XmlHttpReq.DONE){
				fCleanTransport(RequestObj);
				RequestObj.abort();
			}
		};
		if(bAsync) window.attachEvent("onunload",fOnUnload);
	}

	this._object.onreadystatechange=function(){
		if(bGecko && !bAsync)	return;
		RequestObj.readyState=RequestObj._object.readyState;
		fSynchronizeValues(RequestObj);
		if(RequestObj._aborted){
			RequestObj.readyState=XmlHttpReq.UNSENT;
			return;
		}
		if(RequestObj.readyState==XmlHttpReq.DONE){
			fCleanTransport(RequestObj);
			if(bIE && bAsync)	window.detachEvent("onunload",fOnUnload); // IE - memory leak in interrupted
		}
		if(nState != RequestObj.readyState)
			fReadyStateChange(RequestObj);
		nState=RequestObj.readyState;
	};

	if(XmlHttpReq.onopen)	XmlHttpReq.onopen.apply(this,arguments); // Method sniffer
	if(arguments.length > 4) this._object.open(sMethod,sUrl,bAsync,sUser,sPassword);
	else if(arguments.length > 3) this._object.open(sMethod,sUrl,bAsync,sUser);
	else this._object.open(sMethod,sUrl,bAsync);

	if(!bAsync && bGecko){
		this.readyState=XmlHttpReq.OPENED;
		fReadyStateChange(this);
	}
};

XmlHttpReq.prototype.send=function(dta){
	if(XmlHttpReq.onsend)	XmlHttpReq.onsend.apply(this,arguments);
	if(dta && dta.nodeType){
		dta=window.XMLSerializer ? new window.XMLSerializer().serializeToString(dta) : dta.xml;
		if(!this._headers["Content-Type"]) this._object.setRequestHeader("Content-Type","application/xml");
	}

	this._object.send(dta);
	if(bGecko && !this._async){
		this.readyState=XmlHttpReq.OPENED;
		fSynchronizeValues(this);
		while(this.readyState < XmlHttpReq.DONE){
			this.readyState++;
			fReadyStateChange(this);
			if(this._aborted)
				return;
		}
	}
};

XmlHttpReq.prototype.abort=function(){
	if(XmlHttpReq.onabort) XmlHttpReq.onabort.apply(this,arguments);
	if(this.readyState > XmlHttpReq.UNSENT) this._aborted=true;

	this._object.abort();
	fCleanTransport(this);
};

XmlHttpReq.prototype.getAllResponseHeaders=function(){
	return this._object.getAllResponseHeaders();
};

XmlHttpReq.prototype.getResponseHeader=function(name){
	return this._object.getResponseHeader(name);
};

XmlHttpReq.prototype.setRequestHeader=function(name,val){
	if(!this._headers) this._headers={};
	this._headers[name]=val;
	return this._object.setRequestHeader(name,val);
};

XmlHttpReq.prototype.addEventListener=function(name,fHandler,bUseCapture){
	for(var i=0,ListenerObj; ListenerObj=this._listeners[i]; i++)
		if(ListenerObj[0]==name && ListenerObj[1]==fHandler && ListenerObj[2]==bUseCapture) return;
	this._listeners.push([name,fHandler,bUseCapture]);
};

XmlHttpReq.prototype.removeEventListener=function(name,fHandler,bUseCapture){
	for(var i=0,ListenerObj; ListenerObj=this._listeners[i]; i++)
		if(ListenerObj[0]==name && ListenerObj[1]==fHandler && ListenerObj[2]==bUseCapture) break;
	if(ListenerObj) this._listeners.splice(i,1);
};

XmlHttpReq.prototype.dispatchEvent=function(EventObj){
	var EventObj={'type':EventObj.type,'target':this,'currentTarget':this,'eventPhase':2,'bubbles':EventObj.bubbles,'cancelable':EventObj.cancelable,'timeStamp':EventObj.timeStamp,'stopPropagation':function(){},'preventDefault':function(){},'initEvent':function(){}};
	if(EventObj.type=="readystatechange" && this.onreadystatechange)
		(this.onreadystatechange.handleEvent || this.onreadystatechange).apply(this,[EventObj]);
  if (this._listeners[i] != null) //MW 
  {
	  for(var i=0,ListenerObj; ListenerObj=this._listeners[i]; i++)
		  if(ListenerObj[0]==EventObj.type && !ListenerObj[2]) (ListenerObj[1].handleEvent || ListenerObj[1]).apply(this,[EventObj]);
  }
};

XmlHttpReq.prototype.toString=function(){
	return '[' + "object" + ' ' + "XMLHttpRequest" + ']';
};

XmlHttpReq.toString=function(){
	return '[' + "XMLHttpRequest" + ']';
};

function fReadyStateChange(RequestObj){
	if(XmlHttpReq.onreadystatechange)	XmlHttpReq.onreadystatechange.apply(RequestObj);
	RequestObj.dispatchEvent({'type':"readystatechange",'bubbles':false,'cancelable':false,'timeStamp':new Date + 0});
};

function fGetDocument(RequestObj){
	var DocumentObj=RequestObj.responseXML;
	if(bIE && DocumentObj && !DocumentObj.documentElement && RequestObj.getResponseHeader("Content-Type").match(/[^\/]+\/[^\+]+\+xml/)){
		DocumentObj=new window.ActiveXObject("Microsoft.XMLDOM");
		DocumentObj.loadXML(RequestObj.responseText);
	}
	if(DocumentObj)
		if((bIE && DocumentObj.parseError != 0) || (DocumentObj.documentElement && DocumentObj.documentElement.tagName=="parsererror"))
			return null;
	return DocumentObj;
};

function fSynchronizeValues(RequestObj){
	try{RequestObj.responseText=RequestObj._object.responseText;} catch(e){}
	try{RequestObj.responseXML=fGetDocument(RequestObj._object);} catch(e){}
	try{RequestObj.status=RequestObj._object.status;} catch(e){}
	try{RequestObj.statusText=RequestObj._object.statusText;} catch(e){}
};

function fCleanTransport(RequestObj){
	RequestObj._object.onreadystatechange=new window.Function;
	delete RequestObj._headers;
};

if(!window.Function.prototype.apply){
	window.Function.prototype.apply=function(RequestObj,ArgObj){
		if(!ArgObj)
			ArgObj=[];
			RequestObj.__func=this;
			RequestObj.__func(ArgObj[0],ArgObj[1],ArgObj[2],ArgObj[3],ArgObj[4]);
			delete RequestObj.__func;
		};
	};
	window.XMLHttpRequest=XmlHttpReq;
})();
